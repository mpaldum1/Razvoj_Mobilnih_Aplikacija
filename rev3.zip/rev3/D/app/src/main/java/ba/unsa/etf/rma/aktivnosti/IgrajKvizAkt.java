package ba.unsa.etf.rma.aktivnosti;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;

public class IgrajKvizAkt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        Kviz k = getIntent().getParcelableExtra("kviz");
        Bundle bundle = new Bundle();
        bundle.putParcelable("kviz", k);

        FragmentManager fragmentManager = getSupportFragmentManager();
        PitanjeFrag pitanjeFrag = new PitanjeFrag();
        pitanjeFrag.setArguments(bundle);
        fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag, pitanjeFrag.getTag()).commit();

        InformacijeFrag informacijeFrag = new InformacijeFrag();
        informacijeFrag.setArguments(bundle);
        fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag, informacijeFrag.getTag()).commit();

    }
}
