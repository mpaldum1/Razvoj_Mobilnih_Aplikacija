package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class AdapterZaGridView extends ArrayAdapter<Kviz> {

    private ArrayList<Kviz> list = new ArrayList<>();
    private Context context;

    public AdapterZaGridView(Context context, int resource, ArrayList<Kviz> objects) {
        super(context, resource, objects);
        list = objects;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.grid_view_item, parent, false);
        }

        Kviz trenutniKviz = list.get(position);

        IconView image = (IconView) listItem.findViewById(R.id.ikona);


        if(position == list.size() - 1) {
            image.setImageResource(R.drawable.add_icon);
        } else if(trenutniKviz.getKategorija().equals(new Kategorija("Svi", null))) {
            image.setImageResource(R.drawable.bluecircle1);
            TextView brojPitanja = (TextView) listItem.findViewById(R.id.brojPitanja);
            brojPitanja.setText(String.valueOf(trenutniKviz.getPitanja().size()));
        } else {
            image.setIcon(Integer.parseInt(trenutniKviz.getKategorija().getId()));
            TextView brojPitanja = (TextView) listItem.findViewById(R.id.brojPitanja);
            brojPitanja.setText(String.valueOf(trenutniKviz.getPitanja().size()));
        }
        TextView naziv = (TextView) listItem.findViewById(R.id.nazivKviza);
        naziv.setText(trenutniKviz.getNaziv());


        return listItem;
    }

}
