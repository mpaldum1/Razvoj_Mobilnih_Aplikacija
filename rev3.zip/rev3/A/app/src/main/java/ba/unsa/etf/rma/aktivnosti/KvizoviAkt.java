package ba.unsa.etf.rma.aktivnosti;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.AdapterKategorija;
import ba.unsa.etf.rma.AdapterKviz;
import ba.unsa.etf.rma.ProcitajBazuKategorija;
import ba.unsa.etf.rma.ProcitajBazuKvizova;
import ba.unsa.etf.rma.ProcitajBazuPitanja;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.R;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnItemClick {


    Spinner spinner;
    ListView listView;
    AdapterKategorija adapter;
    AdapterKviz adapter2;
    ArrayList<Kategorija> kategorije= new ArrayList<>();
    ArrayList<Kviz> kvizovi= new ArrayList<>();
    ArrayList<Kviz> trenutniKvizovi= new ArrayList<>();
    Kategorija sveKategorije = new Kategorija("Svi","svi");
    Kviz dodajKviz = new Kviz("Dodaj kviz", null, null);
    Kategorija kategorija;
    private FragmentManager fragmentManager;
    private FrameLayout listaFrameLayout;
    private ListaFrag listaFrag;
    private DetailFrag detailFrag;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private ArrayList<String> dokumentPitanja = new ArrayList<>();
    private ArrayList<String> dokumentKategorija = new ArrayList<>();
    private ArrayList<String> dokumentKvizova = new ArrayList<>();
    private Context con = this;
    private Boolean horizontalnaPromjena = false;
    private int pozicijaPromjene = -1;


    public class ProcitajBazuKategorija extends AsyncTask<String, Void, Void> {

        private Context con;

        public ProcitajBazuKategorija(Context c) {
            con = c;
        }

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream tajnaStream = con.getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();

                String url = "https://firestore.googleapis.com/v1/projects/projekatspirala/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN,"UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) !=null ) {
                        response.append(responseLine.trim() + "\n");
                    }
                    String inputStream = response.toString();
                    try {
                        JSONObject jo = new JSONObject(inputStream);
                        JSONArray dokumenti = jo.getJSONArray("documents");
                        for (int i=0; i< dokumenti.length(); i++) {
                            JSONObject kata = dokumenti.getJSONObject(i);
                            String str = kata.getString("name");
                            String[] dijelovi = str.split("/");
                            String dokumentId = dijelovi[6];
                            JSONObject konkretnaKata = kata.getJSONObject("fields");
                            JSONObject nazivKate = konkretnaKata.getJSONObject("naziv");
                            JSONObject idKate = konkretnaKata.getJSONObject("idIkonice");
                            String n = nazivKate.getString("stringValue");
                            String id = idKate.getString("integerValue");
                            boolean postojiKategorija = false;
                            for (int j=0; j<kategorije.size(); j++) {
                                if (kategorije.get(j).getNaziv().equals(n) || kategorije.get(j).getId().equals(id))
                                    postojiKategorija = true;
                            }
                            if (!postojiKategorija) {
                                kategorije.add(new Kategorija(n, id));
                                dokumentKategorija.add(dokumentId);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                conn.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            if (KvizoviAkt.this.findViewById(R.id.listPlace) == null)
            adapter.notifyDataSetChanged();

            new ProcitajBazuPitanja(con).execute("dsd");

        }
    }




    public class ProcitajBazuPitanja extends AsyncTask<String, Void, Void> {

        private Context con;

        public ProcitajBazuPitanja(Context c) {
            con = c;
        }

        @Override
        protected Void doInBackground(String... strings) {

        GoogleCredential credentials;
        try {
            InputStream tajnaStream = con.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/projekatspirala/databases/(default)/documents/Pitanja?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN,"UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim() + "\n");
                }
                String inputStream = response.toString();
                try {
                    JSONObject jo = new JSONObject(inputStream);
                    JSONArray dokumenti = jo.getJSONArray("documents");
                    for (int i=0; i< dokumenti.length(); i++) {
                        JSONObject jedno = dokumenti.getJSONObject(i);
                        String str = jedno.getString("name");
                        String[] dijelovi = str.split("/");
                        String dokumenPitanja = dijelovi[6];
                        JSONObject konkretnoPitanje = jedno.getJSONObject("fields");
                        JSONObject nazivPitanja = konkretnoPitanje.getJSONObject("naziv");
                        JSONObject indexTacnogPitanja = konkretnoPitanje.getJSONObject("indexTacnog");
                        JSONObject lOdg = konkretnoPitanje.getJSONObject("odgovori");
                        JSONObject lOdgovora = lOdg.getJSONObject("arrayValue");
                        JSONArray listaOdgovora = lOdgovora.getJSONArray("values");

                        ArrayList<String> odgovori = new ArrayList<>();
                        for (int j=0; j<listaOdgovora.length(); j++) {
                            JSONObject jedanOdg = listaOdgovora.getJSONObject(j);
                            String value = jedanOdg.getString("stringValue");
                            odgovori.add(value);
                        }

                        String n = nazivPitanja.getString("stringValue");
                        String index = indexTacnogPitanja.getString("integerValue");
                        boolean postojiPitanje = false;
                        for (int j=0; j<pitanja.size(); j++) {
                            if (pitanja.get(j).getNaziv().equals(n))
                                postojiPitanje = true;
                        }


                            if (!postojiPitanje) {
                                pitanja.add(new Pitanje(n, n, odgovori, odgovori.get(Integer.parseInt(index))));
                                dokumentPitanja.add(dokumenPitanja);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            if (KvizoviAkt.this.findViewById(R.id.listPlace) == null) {

            }

            else {

                if (horizontalnaPromjena) {
                    new ProcitajBazuKvizova(con, kategorije.get(pozicijaPromjene)).execute("dsd");
                }
                else {
                    new ProcitajBazuKvizova(con, sveKategorije).execute("dsd");
                }
            }

        }
    }







    public class ProcitajBazuKvizova extends AsyncTask<String, Void, Void> {



        private Context con;
        private Kategorija trenutnaKategorija;

        public ProcitajBazuKvizova(Context c, Kategorija k) {
            con = c;
            trenutnaKategorija = k;
        }



        @Override
        protected Void doInBackground(String... strings) {
        GoogleCredential credentials;
        try {
            InputStream tajnaStream = con.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/projekatspirala/databases/(default)/documents/Kvizovi?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN,"UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim() + "\n");
                }
                String inputStream = response.toString();
                try {
                    JSONObject jo = new JSONObject(inputStream);
                    JSONArray dokumenti = jo.getJSONArray("documents");
                    for (int i=0; i< dokumenti.length(); i++) {
                        JSONObject jedno = dokumenti.getJSONObject(i);
                        String str = jedno.getString("name");
                        String[] dijelovi = str.split("/");
                        String dokumentKviza = dijelovi[6];
                        JSONObject konkretanKviz = jedno.getJSONObject("fields");
                        JSONObject nazivKviza = konkretanKviz.getJSONObject("naziv");
                        JSONObject idKat = konkretanKviz.getJSONObject("idKategorije");
                        JSONObject lPit = konkretanKviz.getJSONObject("pitanja");
                        JSONObject lPitanja = lPit.getJSONObject("arrayValue");
                        ArrayList<String> pitanjaS = new ArrayList<>();
                        if (lPitanja.has("values")) {
                            JSONArray listaPitanja = lPitanja.getJSONArray("values");


                            for (int j = 0; j < listaPitanja.length(); j++) {
                                JSONObject jedanOdg = listaPitanja.getJSONObject(j);
                                String value = jedanOdg.getString("stringValue");
                                pitanjaS.add(value); // LISTA ID PITANJA
                            }

                        }

                        String n = nazivKviza.getString("stringValue"); //NAZIV KVIZA
                        String idKatString = idKat.getString("stringValue"); // ID KATEGORIJE

                        ArrayList<Pitanje> potrebnaPitanja = new ArrayList<>();

                        for (int j=0; j<pitanjaS.size(); j++) {
                            for (int k=0; k<pitanja.size(); k++) {
                                if (pitanjaS.get(j).equals(dokumentPitanja.get(k)))
                                    potrebnaPitanja.add(pitanja.get(k));
                            }
                        }

                        Kategorija potrebnaKategorija = new Kategorija("Svi","svi");

                        for (int j=0; j<dokumentKategorija.size(); j++) {
                            if (dokumentKategorija.get(j).equals(idKatString))
                                potrebnaKategorija = kategorije.get(j+1);
                        }



                        boolean postojiKviz = false;
                        for (int j=0; j<kvizovi.size(); j++) {
                            if (kvizovi.get(j).getNaziv().equals(n))
                                postojiKviz = true;
                        }
                        if (!postojiKviz) {
                            if (trenutnaKategorija.getNaziv().equals("Svi")) {
                                kvizovi.add(new Kviz(n, potrebnaPitanja, potrebnaKategorija));
                                dokumentKvizova.add(dokumentKviza);
                            }
                            else {
                                if (trenutnaKategorija.getNaziv().equals(potrebnaKategorija.getNaziv()) && trenutnaKategorija.getId().equals(potrebnaKategorija.getId())) {
                                    kvizovi.add(new Kviz(n, potrebnaPitanja, potrebnaKategorija));
                                    dokumentKvizova.add(dokumentKviza);
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

            return null;
        }

        @Override
        protected void onPreExecute() {

            kvizovi.clear();
            dokumentKvizova.clear();

        }

        @Override
        protected void onPostExecute(Void aVoid) {



            kvizovi.add(dodajKviz);
            if (KvizoviAkt.this.findViewById(R.id.listPlace) == null) {
                adapter2.notifyDataSetChanged();
            }
            else {

                if (listaFrag == null) {
                    listaFrag = new ListaFrag();
                    Bundle argumenti = new Bundle();
                    argumenti.putSerializable("listaKategorija", kategorije);
                    listaFrag.setArguments(argumenti);
                    fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
                }

                if (detailFrag == null) {
                    detailFrag = new DetailFrag();
                    Bundle argumenti2 = new Bundle();
                    argumenti2.putSerializable("potrebniKvizovi", kvizovi);
                    argumenti2.putSerializable("kategorije", kategorije);
                    argumenti2.putSerializable("dokumentKviza", dokumentKvizova);
                    detailFrag.setArguments(argumenti2);
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }

                if (horizontalnaPromjena) {
                    listaFrag = new ListaFrag();
                    Bundle argumenti = new Bundle();
                    argumenti.putSerializable("listaKategorija", kategorije);
                    listaFrag.setArguments(argumenti);
                    fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();


                    detailFrag = new DetailFrag();
                    Bundle argumenti2 = new Bundle();

                    argumenti2.putSerializable("potrebniKvizovi", kvizovi);
                    argumenti2.putSerializable("kategorije", kategorije);
                    argumenti2.putSerializable("dokumentKviza", dokumentKvizova);
                    detailFrag.setArguments(argumenti2);
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }


            }

        }
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);
        horizontalnaPromjena = false;
        pozicijaPromjene = -1;

        con = this;
        kategorije.clear();
        pitanja.clear();
        dokumentPitanja.clear();
        dokumentKategorija.clear();
        dokumentKvizova.clear();
        kategorije.add(sveKategorije);
        kvizovi.clear();

        new ProcitajBazuKategorija(this).execute("dsd");
        Toast.makeText(KvizoviAkt.this, "Ucitavanje aplikacije u toku", Toast.LENGTH_LONG).show();


        if (KvizoviAkt.this.findViewById(R.id.listPlace) == null) {

            listView = (ListView) findViewById(R.id.lvKvizovi);
            adapter2 = new AdapterKviz(this, R.layout.ikone, kvizovi);
            listView.setAdapter(adapter2);
            spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
            adapter = new AdapterKategorija(this, android.R.layout.simple_spinner_item, kategorije);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setSelection(0);


            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    kategorija = adapter.getItem(position);
                    dokumentKvizova.clear();
                    kvizovi.clear();

                        new ProcitajBazuKvizova(con,kategorija).execute("dsd");

                    adapter.notifyDataSetChanged();
                    adapter2.notifyDataSetChanged();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


            listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                    Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                    String azuriranje = "ne";

                    if (kvizovi.get(position) != dodajKviz) {
                        azuriranje = "da";
                        myIntent.putExtra("dokumentKviza", dokumentKvizova.get(position));

                    }

                    myIntent.putExtra("azuriranje", azuriranje);

                    KvizoviAkt.this.startActivity(myIntent);

                    return true;

                }
            });


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    if (kvizovi.get(position) == dodajKviz) return;

                    Intent igranjeKviza = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                    igranjeKviza.putExtra("dokumentKviza", dokumentKvizova.get(position));
                    KvizoviAkt.this.startActivity(igranjeKviza);


                }
            });

        }


        else {

            fragmentManager = getSupportFragmentManager();
            listaFrameLayout = (FrameLayout) findViewById(R.id.listPlace);
            listaFrag = (ListaFrag) fragmentManager.findFragmentById(R.id.listPlace);


            fragmentManager = getSupportFragmentManager();
            listaFrameLayout = (FrameLayout) findViewById(R.id.detailPlace);
            detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);

        }

    }


    public void onItemClicked(int pos) {

        horizontalnaPromjena = true;
        pozicijaPromjene = pos;

        kvizovi.clear();
        dokumentKvizova.clear();

        new ProcitajBazuKategorija(this).execute("dsd");


    }


    }
