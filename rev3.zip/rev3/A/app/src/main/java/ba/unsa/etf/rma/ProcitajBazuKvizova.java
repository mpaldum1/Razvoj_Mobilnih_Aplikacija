package ba.unsa.etf.rma;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class ProcitajBazuKvizova extends AsyncTask<String, Void, Void> {



    private Context con;
    private ArrayList<Kviz> kvizovi= new ArrayList<>();
    private ArrayList<Pitanje> pitanjaKviza = new ArrayList<>();
    private ArrayList<Kategorija> kategorije = new ArrayList<>();
    private ArrayList<String> dokumentSvihPitanja = new ArrayList<>();
    private ArrayList<String> dokumentKategorija = new ArrayList<>();
    private ArrayList<String> dokumentKvizova = new ArrayList<>();
    private Kategorija trenutnaKategorija;

    public ProcitajBazuKvizova(Context c, ArrayList<Kviz> k, ArrayList<Pitanje> p, ArrayList<String> s, ArrayList<Kategorija> k1, ArrayList<String> s1, Kategorija k2, ArrayList<String> s2) {
        con = c;
        kvizovi = k;
        pitanjaKviza = p;
        dokumentSvihPitanja = s;
        kategorije = k1;
        dokumentKategorija = s1;
        trenutnaKategorija = k2;
        dokumentKvizova = s2;
    }



    @Override
    protected Void doInBackground(String... strings) {
        /*
        GoogleCredential credentials;
        try {
            InputStream tajnaStream = con.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();

            String url = "https://firestore.googleapis.com/v1/projects/projekatspirala/databases/(default)/documents/Kvizovi?access_token=";
            URL urlObj = new URL(url + URLEncoder.encode(TOKEN,"UTF-8"));
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            InputStream odgovor = conn.getInputStream();
            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) !=null ) {
                    response.append(responseLine.trim() + "\n");
                }
                String inputStream = response.toString();
                try {
                    JSONObject jo = new JSONObject(inputStream);
                    JSONArray dokumenti = jo.getJSONArray("documents");
                    for (int i=0; i< dokumenti.length(); i++) {
                        JSONObject jedno = dokumenti.getJSONObject(i);
                        String str = jedno.getString("name");
                        String[] dijelovi = str.split("/");
                        String dokumentKviza = dijelovi[6];
                        JSONObject konkretanKviz = jedno.getJSONObject("fields");
                        JSONObject nazivKviza = konkretanKviz.getJSONObject("naziv");
                        JSONObject idKat = konkretanKviz.getJSONObject("idKategorije");
                        JSONObject lPit = konkretanKviz.getJSONObject("pitanja");
                        JSONObject lPitanja = lPit.getJSONObject("arrayValue");
                        ArrayList<String> pitanja = new ArrayList<>();
                        if (lPitanja.has("values")) {
                            JSONArray listaPitanja = lPitanja.getJSONArray("values");


                            for (int j = 0; j < listaPitanja.length(); j++) {
                                JSONObject jedanOdg = listaPitanja.getJSONObject(j);
                                String value = jedanOdg.getString("stringValue");
                                pitanja.add(value); // LISTA ID PITANJA
                            }

                        }

                        String n = nazivKviza.getString("stringValue"); //NAZIV KVIZA
                        String idKatString = idKat.getString("stringValue"); // ID KATEGORIJE

                        ArrayList<Pitanje> potrebnaPitanja = new ArrayList<>();

                        for (int j=0; j<pitanja.size(); j++) {
                            for (int k=0; k<pitanjaKviza.size(); k++) {
                                if (pitanja.get(j).equals(dokumentSvihPitanja.get(k)))
                                    potrebnaPitanja.add(pitanjaKviza.get(k));
                            }
                        }

                        Kategorija potrebnaKategorija = new Kategorija("Svi","svi");

                        for (int j=0; j<dokumentKategorija.size(); j++) {
                            if (dokumentKategorija.get(j).equals(idKatString))
                                potrebnaKategorija = kategorije.get(j);
                        }



                        boolean postojiKviz = false;
                        for (int j=0; j<kvizovi.size(); j++) {
                            if (kvizovi.get(j).getNaziv().equals(n))
                                postojiKviz = true;
                        }
                        if (!postojiKviz) {
                            if (trenutnaKategorija.getNaziv().equals("Svi")) {
                                kvizovi.add(new Kviz(n, potrebnaPitanja, potrebnaKategorija));
                                dokumentKvizova.add(dokumentKviza);
                            }
                            else {
                                if (trenutnaKategorija.getNaziv().equals(potrebnaKategorija.getNaziv()) && trenutnaKategorija.getId().equals(potrebnaKategorija.getId())) {
                                    kvizovi.add(new Kviz(n, potrebnaPitanja, potrebnaKategorija));
                                    dokumentKvizova.add(dokumentKviza);
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        */

        return null;
    }


}