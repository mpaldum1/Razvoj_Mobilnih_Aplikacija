package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;


public class InformacijeFrag extends Fragment {

    private Kviz kviz;
    private String naziv = new String();
    private String brojTacnih = new String();
    private String brojPreostalih = new String();
    private String procenatTacnih = new String();
    private Button krajIgre;
    private int tacni = 0;
    private int ukupni = 0;
    private int preostali =0;
    private double procent = 0;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View iv = inflater.inflate(R.layout.informacije_frag, container, false);

        krajIgre = (Button) iv.findViewById(R.id.btnKraj);


        if (getArguments()!=null) {


            kviz = (Kviz) getArguments().getSerializable("kviz");
            tacni = getArguments().getInt("brojTacnih");
            ukupni = getArguments().getInt("ukupniBrojPitanja");
            preostali = getArguments().getInt("brojPreostalih");

            naziv = kviz.getNaziv();
            brojTacnih = Integer.toString(tacni);
            brojPreostalih = Integer.toString(preostali);
            if (ukupni!=0) procent =((double)tacni/(double)ukupni)*100;
            else procent = 0;

            procenatTacnih = Integer.toString((int) procent)+"%";


            TextView nazivKviza = (TextView) iv.findViewById(R.id.infNazivKviza);
            TextView brojTacnihPitanja = (TextView) iv.findViewById(R.id.infBrojTacnihPitanja);
            TextView brojPreostalihPitanja = (TextView) iv.findViewById(R.id.infBrojPreostalihPitanja);
            TextView procenatTacnihPitanja = (TextView) iv.findViewById(R.id.infProcenatTacni);


            nazivKviza.setText(naziv);
            brojTacnihPitanja.setText(brojTacnih);
            brojPreostalihPitanja.setText(brojPreostalih);
            procenatTacnihPitanja.setText(procenatTacnih);
        }

        krajIgre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });




        return iv;
    }




}
