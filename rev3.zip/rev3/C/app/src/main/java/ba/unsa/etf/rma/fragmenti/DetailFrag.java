package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizAdapter2;
import ba.unsa.etf.rma.klase.Pitanje;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class DetailFrag extends Fragment {
    private GridView gridKvizovi;
    private KvizAdapter2 adapter;
    private ArrayList<Kviz> kvizovi = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detail, container, false);
        gridKvizovi = (GridView) view.findViewById(R.id.gridKvizovi);
        ArrayList<Kviz> noviKvizovi = getArguments().getParcelableArrayList("kvizovi");
        kvizovi.addAll(noviKvizovi);
        Resources res = getResources();
        adapter = new KvizAdapter2(getActivity(), kvizovi, res);
        gridKvizovi.setAdapter(adapter);

        gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (!KvizoviAkt.filtrirano2) {
                    if (position != kvizovi.size() - 1) {
                        Intent myIntent = new Intent(getActivity(), IgrajKvizAkt.class);
                        myIntent.putExtra("nazivKviza", kvizovi.get(position).getNaziv());
                        myIntent.putExtra("pitanja", kvizovi.get(position).getPitanja());
                        getActivity().startActivityForResult(myIntent, 2);
                    }
                } else {
                    if (position != KvizoviAkt.filterKvizovi2.size() - 1) {
                        Intent myIntent = new Intent(getActivity(), IgrajKvizAkt.class);
                        myIntent.putExtra("nazivKviza", KvizoviAkt.filterKvizovi2.get(position).getNaziv());
                        myIntent.putExtra("pitanja", KvizoviAkt.filterKvizovi2.get(position).getPitanja());
                        getActivity().startActivityForResult(myIntent, 2);
                    }
                }
            }
        });

        gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (!KvizoviAkt.filtrirano2) {
                    if (position == kvizovi.size() - 1) {
                        Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                        getActivity().startActivityForResult(myIntent, 0);
                    } else {
                        Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                        myIntent.putExtra("nazivKviza", kvizovi.get(position).getNaziv());
                        myIntent.putExtra("kategorija", kvizovi.get(position).getKategorija());
                        myIntent.putExtra("pitanja", kvizovi.get(position).getPitanja());
                        KvizoviAkt.pozicija = position;
                        getActivity().startActivityForResult(myIntent, 1);
                    }
                } else {
                    if (position == KvizoviAkt.filterKvizovi2.size() - 1) {
                        Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                        getActivity().startActivityForResult(myIntent, 0);
                    } else {
                        Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                        myIntent.putExtra("nazivKviza", KvizoviAkt.filterKvizovi2.get(position).getNaziv());
                        myIntent.putExtra("kategorija", KvizoviAkt.filterKvizovi2.get(position).getKategorija());
                        myIntent.putExtra("pitanja", KvizoviAkt.filterKvizovi2.get(position).getPitanja());
                        KvizoviAkt.pozicija = position;
                        getActivity().startActivityForResult(myIntent, 1);
                    }
                }
                return true;
            }
        });

        return view;
    }
}
