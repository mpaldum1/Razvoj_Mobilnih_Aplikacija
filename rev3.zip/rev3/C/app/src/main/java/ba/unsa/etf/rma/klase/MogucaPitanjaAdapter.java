package ba.unsa.etf.rma.klase;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class MogucaPitanjaAdapter extends BaseAdapter implements View.OnClickListener {

    private Activity activity;
    private ArrayList pitanja;
    private static LayoutInflater inflater = null;
    public Resources res;
    Pitanje pitanje = null;
    int i = 0;

    @Override
    public void onClick(View v) {
    }

    public static class ViewHolder{
        public TextView naziv;
        public IconView ikona;
    }

    public MogucaPitanjaAdapter(Activity activity, ArrayList data, Resources res) {
        this.activity = activity;
        this.pitanja = data;
        this.res = res;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        if (pitanja.size() <= 0)
            return 1;
        return pitanja.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        MogucaPitanjaAdapter.ViewHolder holder;
        if (convertView == null) {
            v = inflater.inflate(R.layout.element_liste, null);
            holder = new MogucaPitanjaAdapter.ViewHolder();
            holder.naziv = (TextView) v.findViewById(R.id.Itemname);
            holder.ikona = (IconView) v.findViewById(R.id.icon);
            v.setTag(holder);
        }
        else {
            holder = (MogucaPitanjaAdapter.ViewHolder) v.getTag();
        }
        if (pitanja.size() <= 0) {
            holder.naziv.setText(R.string.nema_info);
            holder.ikona.setImageResource(0);
        }
        if(pitanja.size() > 0) {
            pitanje = (Pitanje) pitanja.get(position);
            holder.naziv.setText(pitanje.getNaziv());
            holder.ikona.setImageResource(R.drawable.plus);
            //v.setOnClickListener(new AdapterView.OnItemClickListener(position));
        }
        return v;
    }
}
