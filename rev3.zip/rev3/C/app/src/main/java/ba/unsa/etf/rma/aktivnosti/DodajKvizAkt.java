package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.MogucaPitanjaAdapter;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.DodanaPitanjeAdapter;

public class DodajKvizAkt extends AppCompatActivity {
    private Spinner spKategorije;
    private EditText etNaziv;
    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private Button btnDodajKviz;
    private Button btnImportKviz;
    private ArrayList<Pitanje> pitanja = new ArrayList<Pitanje>();
    private ArrayList<Pitanje> mogucaPitanja = new ArrayList<Pitanje>();
    private ArrayList<Kategorija> kategorije = new ArrayList<Kategorija>();
    private DodanaPitanjeAdapter adapter;
    private MogucaPitanjaAdapter adapterMoguce;
    private KategorijeAdapter adapterKategorije;
    private boolean ima = false;
    public static ArrayList<Pitanje> validacijaPitanja = new ArrayList<>();
    public static ArrayList<Kategorija> validacijaKategorija = new ArrayList<>();
    private Kviz novi = new Kviz();
    private boolean ispravnaDatoteka = true;
    ArrayList<Pitanje> novaPitanja = new ArrayList<>();
    public Kviz kvizZaBazu = new Kviz();
    public Kviz kvizZaBazuEdit = new Kviz();
    public static String idKvizaZaEdit = "";

    public class EditovanjeKvizovaKlasa extends AsyncTask<String, Void, Void> {

        AsyncResponse ar = null;

        public EditovanjeKvizovaKlasa(AsyncResponse asyncResponse) {
            this.ar = asyncResponse;
        }

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);

                System.out.println("STRING JEEEEEE:  " + strings[1]);

                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kvizovi/" + strings[0] + "?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("PATCH");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + etNaziv.getText().toString() + "\"}";
                if (spKategorije.getSelectedItemPosition() == 1) {
                    dokument += ", \"idKategorije\": { \"stringValue\" : \"Svi\"}";
                } else if (spKategorije.getSelectedItemPosition() == 0) {
                    if(strings[1].length() == 0){
                        dokument += ", \"idKategorije\": { \"stringValue\" : \"Svi\"}";
                    }
                    else dokument += ", \"idKategorije\": { \"stringValue\" : \"" + strings[1] + "\"}";
                } else {
                    dokument += ", \"idKategorije\": ";
                    for (int i = 0; i < KvizoviAkt.pocetneKategorijeIzBaze.size(); i++) {
                        if (KvizoviAkt.pocetneKategorijeIzBaze.get(i).second.getNaziv().equals(kvizZaBazuEdit.getKategorija().getNaziv())) {
                            dokument += "{\"stringValue\" : \"" + KvizoviAkt.pocetneKategorijeIzBaze.get(i).first + "\"}";
                            break;
                        }
                    }
                }
                DodajPitanjeAkt.idPitanja.clear();
                    for (int i = 0; i < KvizoviAkt.pocetnaPitanjaIzBaze.size(); i++) {
                        for (int j = 0; j < kvizZaBazuEdit.getPitanja().size(); j++) {
                            if (kvizZaBazuEdit.getPitanja().get(j).getNaziv().equals(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).second.getNaziv())) {
                                DodajPitanjeAkt.idPitanja.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).first);
                            }
                        }
                    }
                dokument += " , \"pitanja\" : { \"arrayValue\" : { \"values\" : [";
                for (int i = 0; i < DodajPitanjeAkt.idPitanja.size(); i++) {
                    if (i != DodajPitanjeAkt.idPitanja.size() - 1) {
                        dokument += "{\"stringValue\" : \"" + DodajPitanjeAkt.idPitanja.get(i) + "\"},";
                    } else {
                        dokument += "{\"stringValue\" : \"" + DodajPitanjeAkt.idPitanja.get(i) + "\"}";
                    }
                }
                dokument += " ] } } } }";

                DodajPitanjeAkt.idPitanja.clear();

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                InputStream odgovor = connection.getInputStream();
                StringBuilder response = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))
                ) {
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                String rezultatKvizovi = response.toString();
                if(!rezultatKvizovi.equals("{}")) {
                    JSONObject joKvizovi = new JSONObject(rezultatKvizovi);
                    JSONObject fields = joKvizovi.getJSONObject("fields");
                    JSONObject stringValue = fields.getJSONObject("naziv");
                    String nazivKviza = stringValue.getString("stringValue");
                    JSONObject referenceValue = fields.getJSONObject("idKategorije");
                    String idKategorijeKviza = referenceValue.getString("stringValue");
                    Kategorija kat = new Kategorija();
                    for (int k = 0; k < KvizoviAkt.pocetneKategorijeIzBaze.size(); k++) {
                        if (idKategorijeKviza.equals(KvizoviAkt.pocetneKategorijeIzBaze.get(k).first)) {
                            kat = KvizoviAkt.pocetneKategorijeIzBaze.get(k).second;
                            break;
                        }
                    }

                    JSONObject pitt = fields.getJSONObject("pitanja");
                    JSONObject arrayValue = pitt.getJSONObject("arrayValue");
                    if(!arrayValue.toString().equals("{}")) {
                        JSONArray values = arrayValue.getJSONArray("values");
                        ArrayList<String> trenutniIdeviPitanja = new ArrayList<>();
                        for (int j = 0; j < values.length(); j++) {
                            JSONObject item = values.getJSONObject(j);
                            String pit = item.getString("stringValue");
                            trenutniIdeviPitanja.add(pit);
                        }
                        ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                        for (int s = 0; s < KvizoviAkt.pocetnaPitanjaIzBaze.size(); s++) {
                            for (int h = 0; h < trenutniIdeviPitanja.size(); h++) {
                                if (trenutniIdeviPitanja.get(h).equals(KvizoviAkt.pocetnaPitanjaIzBaze.get(s).first)) {
                                    pitanjaZaKviz.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(s).second);
                                }
                            }
                        }
                        trenutniIdeviPitanja.clear();
                        Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                        KvizoviAkt.pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(strings[0], trenutniKviz));
                    }
                    else{
                        ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                        Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                        KvizoviAkt.pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(strings[0], trenutniKviz));
                    }
                }
                /*System.out.println("VELICINAAAA LISTE: " + KvizoviAkt.pocetniKvizoviIzBaze.size());
                for(int i = 0; i < KvizoviAkt.pocetniKvizoviIzBaze.size(); i++){
                    System.out.println("ID: " + KvizoviAkt.pocetniKvizoviIzBaze.get(i).first);
                    System.out.println("KVIZZZZZ: " + KvizoviAkt.pocetniKvizoviIzBaze.get(i).second.getNaziv());
                }*/
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class KlasaDodajKviz extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kvizovi?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + etNaziv.getText().toString() + "\"}";
                if (spKategorije.getSelectedItemPosition() != 0) {
                    dokument += ", \"idKategorije\": ";
                    for (int i = 0; i < KvizoviAkt.pocetneKategorijeIzBaze.size(); i++) {
                        if (KvizoviAkt.pocetneKategorijeIzBaze.get(i).second.getNaziv().equals(kvizZaBazu.getKategorija().getNaziv())) {
                            dokument += "{\"stringValue\" : \"" + KvizoviAkt.pocetneKategorijeIzBaze.get(i).first + "\"}";
                            break;
                        }
                    }
                } else {
                    dokument += ", \"idKategorije\": { \"stringValue\" : \"Svi\"}";
                }
                DodajPitanjeAkt.idPitanja.clear();
                for (int i = 0; i < KvizoviAkt.pocetnaPitanjaIzBaze.size(); i++) {
                    for (int j = 0; j < kvizZaBazu.getPitanja().size(); j++) {
                        if (kvizZaBazu.getPitanja().get(j).getNaziv().equals(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).second.getNaziv())) {
                            DodajPitanjeAkt.idPitanja.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).first);
                        }
                    }
                }
                dokument += " , \"pitanja\" : { \"arrayValue\" : { \"values\" : [";
                for (int i = 0; i < DodajPitanjeAkt.idPitanja.size(); i++) {
                    if (i != DodajPitanjeAkt.idPitanja.size() - 1) {
                        dokument += "{\"stringValue\" : \"" + DodajPitanjeAkt.idPitanja.get(i) + "\"},";
                    } else {
                        dokument += "{\"stringValue\" : \"" + DodajPitanjeAkt.idPitanja.get(i) + "\"}";
                    }
                }
                dokument += " ] } } } }";

                DodajPitanjeAkt.idPitanja.clear();

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                InputStream odgovor = connection.getInputStream();
                StringBuilder response = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))
                ) {
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                String rezultatKvizovi = response.toString();
                if(!rezultatKvizovi.equals("{}")) {
                    JSONObject joKvizovi = new JSONObject(rezultatKvizovi);
                    String nameKviza = joKvizovi.getString("name");
                    int brojac3 = 0;
                    for(int kv = 0; kv < nameKviza.length(); kv++){
                        if(nameKviza.charAt(kv) == '/' ){
                            brojac3++;
                        }
                        if(brojac3 == 6){
                            nameKviza = nameKviza.substring(++kv, nameKviza.length());
                            break;
                        }
                    }
                    JSONObject fields = joKvizovi.getJSONObject("fields");
                    JSONObject stringValue = fields.getJSONObject("naziv");
                    String nazivKviza = stringValue.getString("stringValue");
                    JSONObject referenceValue = fields.getJSONObject("idKategorije");
                    String idKategorijeKviza = referenceValue.getString("stringValue");
                    Kategorija kat = new Kategorija();
                    for (int k = 0; k < KvizoviAkt.pocetneKategorijeIzBaze.size(); k++) {
                        if (idKategorijeKviza.equals(KvizoviAkt.pocetneKategorijeIzBaze.get(k).first)) {
                            kat = KvizoviAkt.pocetneKategorijeIzBaze.get(k).second;
                            break;
                        }
                    }

                    JSONObject pitt = fields.getJSONObject("pitanja");
                    JSONObject arrayValue = pitt.getJSONObject("arrayValue");
                    if(!arrayValue.toString().equals("{}")) {
                        JSONArray values = arrayValue.getJSONArray("values");
                        ArrayList<String> trenutniIdeviPitanja = new ArrayList<>();
                        for (int j = 0; j < values.length(); j++) {
                            JSONObject item = values.getJSONObject(j);
                            String pit = item.getString("stringValue");
                            trenutniIdeviPitanja.add(pit);
                        }
                        ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                        for (int s = 0; s < KvizoviAkt.pocetnaPitanjaIzBaze.size(); s++) {
                            for (int h = 0; h < trenutniIdeviPitanja.size(); h++) {
                                if (trenutniIdeviPitanja.get(h).equals(KvizoviAkt.pocetnaPitanjaIzBaze.get(s).first)) {
                                    pitanjaZaKviz.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(s).second);
                                }
                            }
                        }
                        trenutniIdeviPitanja.clear();
                        Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                        KvizoviAkt.pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(nameKviza, trenutniKviz));
                    }
                    else{
                        ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                        Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                        KvizoviAkt.pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(nameKviza, trenutniKviz));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class DodajKategorijuIzImporta extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL (url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + novi.getKategorija().getNaziv() + "\"},  \"idIkonice\": {\"integerValue\":\"26\"}}}";

                try (OutputStream os = connection.getOutputStream())
                {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                InputStream odgovor = connection.getInputStream();
                StringBuilder response = null;
                try(BufferedReader br = new BufferedReader (
                        new InputStreamReader(odgovor, "utf-8"))
                ){
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while((rensponseLine = br.readLine()) != null){
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                String rezultat = response.toString();
                JSONObject jo = new JSONObject(rezultat);
                String name = jo.getString("name");
                JSONObject fields = jo.getJSONObject("fields");
                JSONObject stringValue = fields.getJSONObject("naziv");
                String naziv = stringValue.getString("stringValue");
                JSONObject integerValue = fields.getJSONObject("idIkonice");
                int idIkoniceKategorije = integerValue.getInt("integerValue");
                Kategorija trenutnaKategorija = new Kategorija(naziv, String.valueOf(idIkoniceKategorije));
                //KvizoviAkt.kategorije.add(trenutnaKategorija);
                int brojac = 0;
                for(int i = 0; i < name.length(); i++){
                    if(name.charAt(i) == '/' ){
                        brojac++;
                    }
                    if(brojac == 6){
                        name = name.substring(++i, name.length());
                        break;
                    }
                }
                Pair<String, Kategorija> par = new Pair<String, Kategorija>(name, trenutnaKategorija);
                KvizoviAkt.pocetneKategorijeIzBaze.add(par);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    public class DodajPitanjeIzImporta extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);

                for(int broj = 0; broj < novi.getPitanja().size(); broj++) {
                    String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Pitanja?access_token=";
                    URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                    HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                    connection.setDoOutput(true);
                    connection.setRequestMethod("POST");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Accept", "application/json");

                    int pozicijaTacnog = 0;
                    for(int trazi = 0; trazi < novi.getPitanja().get(broj).getOdgovori().size(); trazi++){
                        if(novi.getPitanja().get(broj).getOdgovori().get(trazi).equals(novi.getPitanja().get(broj).getTacan())){
                            pozicijaTacnog = trazi;
                            break;
                        }
                    }

                    String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + novi.getPitanja().get(broj).getNaziv() + "\"} , \"odgovori\" : { \"arrayValue\" : { \"values\" : [";
                    for (int i = 0; i < novi.getPitanja().get(broj).getOdgovori().size(); i++) {
                        if (i != novi.getPitanja().get(broj).getOdgovori().size() - 1) {
                            dokument += "{\"stringValue\" : \"" + novi.getPitanja().get(broj).getOdgovori().get(i) + "\"},";
                        } else {
                            dokument += "{\"stringValue\" : \"" + novi.getPitanja().get(broj).getOdgovori().get(i) + "\"}";
                        }
                    }
                    dokument += "]}} , \"indexTacnog\": {\"integerValue\":\"" + pozicijaTacnog + "\"}}}";
                    try (OutputStream os = connection.getOutputStream()) {
                        byte[] input = dokument.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }

                    int code = connection.getResponseCode();
                    InputStream odgovor = connection.getInputStream();
                    StringBuilder response = null;
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(odgovor, "utf-8"))
                    ) {
                        response = new StringBuilder();
                        String rensponseLine = null;
                        while ((rensponseLine = br.readLine()) != null) {
                            response.append(rensponseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                    }
                    String rezultat = response.toString();
                    JSONObject jo = new JSONObject(rezultat);
                    String name = jo.getString("name");
                    JSONObject fields = jo.getJSONObject("fields");
                    JSONObject stringValue = fields.getJSONObject("naziv");
                    String naziv = stringValue.getString("stringValue");
                    JSONObject integerValue = fields.getJSONObject("indexTacnog");
                    int indexTacnog = integerValue.getInt("integerValue");
                    JSONObject odgg = fields.getJSONObject("odgovori");
                    JSONObject arrayValue = odgg.getJSONObject("arrayValue");
                    JSONArray values = arrayValue.getJSONArray("values");
                    ArrayList<String> bazaOdgovori = new ArrayList<>();
                    for (int i = 0; i < values.length(); i++) {
                        JSONObject item = values.getJSONObject(i);
                        String odg = item.getString("stringValue");
                        bazaOdgovori.add(odg);
                    }
                    String tacanOdgovorBaza = "";
                    for (int i = 0; i < bazaOdgovori.size(); i++) {
                        if (i == indexTacnog) {
                            tacanOdgovorBaza = bazaOdgovori.get(i);
                            break;
                        }
                    }
                    int brojac = 0;
                    for (int i = 0; i < name.length(); i++) {
                        if (name.charAt(i) == '/') {
                            brojac++;
                        }
                        if (brojac == 6) {
                            name = name.substring(++i, name.length());
                            break;
                        }
                    }
                    DodajPitanjeAkt.idPitanja.add(name);
                    Pitanje novoBazaPitanje = new Pitanje(naziv, naziv, bazaOdgovori, tacanOdgovorBaza);
                    KvizoviAkt.pocetnaPitanjaIzBaze.add(new Pair<String, Pitanje>(name, novoBazaPitanje));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);
        lvDodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);
        spKategorije = (Spinner) findViewById(R.id.spKategorije);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        btnDodajKviz = (Button) findViewById(R.id.btnDodajKviz);
        btnImportKviz = (Button) findViewById(R.id.btnImportKviz);
        etNaziv.setHint("Naziv kviza - INPUT");
        kategorije.add(new Kategorija("Svi"));
        kategorije.add(new Kategorija("Dodaj kategoriju"));
        Resources res = getResources();
        adapterMoguce = new MogucaPitanjaAdapter(this, mogucaPitanja, res);
        if (getIntent().getExtras() != null) {
            etNaziv.setText(getIntent().getStringExtra("nazivKviza"));
            Kategorija novaKategorija = (Kategorija) getIntent().getSerializableExtra("kategorija");
            kategorije.add(0, novaKategorija);
            for (int i = 0; i < KvizoviAkt.pocetniKvizoviIzBaze.size(); i++) {
                if (KvizoviAkt.pocetniKvizoviIzBaze.get(i).second.getNaziv().equals(etNaziv.getText().toString())) {
                    idKvizaZaEdit = KvizoviAkt.pocetniKvizoviIzBaze.get(i).first;
                    break;
                }
            }

            for(int i = 0; i < KvizoviAkt.pocetniKvizoviIzBaze.size(); i++){
                if(idKvizaZaEdit.equals(KvizoviAkt.pocetniKvizoviIzBaze.get(i).first)){
                    KvizoviAkt.pocetniKvizoviIzBaze.remove(i);
                }
            }

            int brojac = 0;
            for (int pit = 0; pit < idKvizaZaEdit.length(); pit++) {
                if (idKvizaZaEdit.charAt(pit) == '/') {
                    brojac++;
                }
                if (brojac == 6) {
                    idKvizaZaEdit = idKvizaZaEdit.substring(++pit, idKvizaZaEdit.length());
                    break;
                }
            }

            for(int i = 0; i < KvizoviAkt.pocetnaPitanjaIzBaze.size(); i++){
                mogucaPitanja.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).second);
            }

            ArrayList<Pitanje> pomocnaMogucaPitanja = new ArrayList<>();
            pomocnaMogucaPitanja.addAll(mogucaPitanja);
            mogucaPitanja.removeAll(mogucaPitanja);
            for (int i = 0; i < KvizoviAkt.kvizovi.size(); i++) {
                if (KvizoviAkt.kvizovi.get(i).getNaziv().equals(etNaziv.getText().toString())) {
                    if (KvizoviAkt.kvizovi.get(i).getPitanja().size() == 0) {

                    } else {
                        for (int j = 0; j < KvizoviAkt.kvizovi.get(i).getPitanja().size(); j++) {
                            for (int k = 0; k < pomocnaMogucaPitanja.size(); k++) {
                                if (pomocnaMogucaPitanja.get(k).getNaziv().equals(KvizoviAkt.kvizovi.get(i).getPitanja().get(j).getNaziv())) {
                                    pomocnaMogucaPitanja.remove(k);
                                }
                            }
                        }

                    }
                }
            }
            mogucaPitanja.addAll(pomocnaMogucaPitanja);
            adapterMoguce.notifyDataSetChanged();
            pomocnaMogucaPitanja.clear();

            for (int i = 2; i < kategorije.size() - 1; i++) {
                if (!kategorije.get(i).getNaziv().equals("Svi"))
                    KvizoviAkt.kategorije.add(new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                for (int j = 0; j < KvizoviAkt.kategorije.size(); j++) {
                    if (!KvizoviAkt.kategorije.get(j).getNaziv().equals("Svi")) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    } else if (!kategorije.get(i).getNaziv().equals("Svi")) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    } else if (!kategorije.get(i).getNaziv().equals(KvizoviAkt.kategorije.get(j).getNaziv())) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    }
                }
            }
            for (int i = 1; i < KvizoviAkt.kategorije.size(); i++) {
                kategorije.add(kategorije.size() - 1, KvizoviAkt.kategorije.get(i));
            }
            ArrayList<Pitanje> listPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("pitanja");
            for (Pitanje pitanje : listPitanja) {
                pitanja.add(new Pitanje(pitanje.getNaziv(), pitanje.getTekstPitanja(), pitanje.getOdgovori(), pitanje.getTacan()));
            }
            boolean neDodaji = false;
            for (int i = 0; i < pitanja.size(); i++) {
                if (pitanja.get(i).getNaziv().equals("Dodaj pitanje")) {
                    neDodaji = true;
                }
            }
            if (!neDodaji) pitanja.add(new Pitanje("Dodaj pitanje", null, null, null));
            KvizoviAkt.imaDodajPitanje = false;

        } else {
            for (int i = 1; i < kategorije.size() - 1; i++) {
                if (!kategorije.get(i).getNaziv().equals("Svi"))
                    KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                for (int j = 0; j < KvizoviAkt.kategorije.size(); j++) {
                    if (!KvizoviAkt.kategorije.get(j).getNaziv().equals("Svi")) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    } else if (!kategorije.get(i).getNaziv().equals("Svi")) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    } else if (!kategorije.get(i).getNaziv().equals(KvizoviAkt.kategorije.get(j).getNaziv())) {
                        KvizoviAkt.kategorije.add(KvizoviAkt.kategorije.size() - 1, new Kategorija(kategorije.get(i).getNaziv(), kategorije.get(i).getId()));
                    }
                }
            }
            for (int i = 1; i < KvizoviAkt.kategorije.size(); i++) {
                //if(KvizoviAkt.kategorije.get(i).getNaziv().equals("Svi")) continue;
                kategorije.add(kategorije.size() - 1, KvizoviAkt.kategorije.get(i));
            }
        }
        if (getIntent().getExtras() == null)
            pitanja.add(new Pitanje("Dodaj pitanje", null, null, null));
        validacijaPitanja.addAll(pitanja);
        validacijaKategorija.addAll(kategorije);
        adapter = new DodanaPitanjeAdapter(this, pitanja, res);
        if (getIntent().getExtras() == null) {
            for(int i = 0; i < KvizoviAkt.pocetnaPitanjaIzBaze.size(); i++){
                mogucaPitanja.add(KvizoviAkt.pocetnaPitanjaIzBaze.get(i).second);
            }
        }
        adapterKategorije = new KategorijeAdapter(this, kategorije, res);
        lvDodanaPitanja.setAdapter(adapter);
        lvMogucaPitanja.setAdapter(adapterMoguce);
        spKategorije.setAdapter(adapterKategorije);
        //if(mogucaPitanja.size() == 0) lvMogucaPitanja.setAdapter(adapterMoguce);

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == pitanja.size() - 1) {
                    Intent myIntent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    DodajKvizAkt.this.startActivityForResult(myIntent, 1);
                } else {
                    mogucaPitanja.add(pitanja.get(position));
                    pitanja.remove(position);
                    adapter.notifyDataSetChanged();
                    adapterMoguce.notifyDataSetChanged();
                }
            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (mogucaPitanja.size() != 0) {
                    Pitanje novo = mogucaPitanja.get(position);
                    pitanja.add(pitanja.size() - 1, novo);
                    mogucaPitanja.remove(position);
                    adapter.notifyDataSetChanged();
                    adapterMoguce.notifyDataSetChanged();
                }
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < KvizoviAkt.validacijaKvizova.size(); i++) {
                    if (KvizoviAkt.validacijaKvizova.get(i).getNaziv().equals(etNaziv.getText().toString())) {
                        ima = true;
                    }
                }
                if (getIntent().getExtras() == null) {
                    if (etNaziv.getText().toString().length() == 0 || ima) {
                        etNaziv.setBackgroundColor(Color.RED);
                        ima = false;
                    } else {
                        //validacijaPitanja.clear();
                        etNaziv.setBackgroundColor(Color.WHITE);
                        Kategorija kat = new Kategorija(kategorije.get(spKategorije.getSelectedItemPosition()).getNaziv(), kategorije.get(spKategorije.getSelectedItemPosition()).getId());
                        Kviz kviz = new Kviz(etNaziv.getText().toString(), pitanja, kat);
                        kvizZaBazu = kviz;
                        new KlasaDodajKviz().execute();
                        Intent returnIntent = getIntent();
                        returnIntent.putExtra("nazivKviza", kviz.getNaziv());
                        returnIntent.putExtra("pitanja", kviz.getPitanja());
                        returnIntent.putExtra("Kategorija", kviz.getKategorija());
                        setResult(RESULT_OK, returnIntent);
                        finish();
                    }
                } else {
                    if (!KvizoviAkt.filtrirano) {
                        for (int i = 0; i < KvizoviAkt.kvizovi.size(); i++) {
                            if (KvizoviAkt.kvizovi.get(i).getNaziv().equals(etNaziv.getText().toString()) && KvizoviAkt.kvizovi.get(KvizoviAkt.pozicija).getNaziv().equals(etNaziv.getText().toString())) {
                                ima = false;
                            }
                        }
                    } else if (KvizoviAkt.filtrirano) {
                        for (int i = 0; i < KvizoviAkt.filterKvizovi.size(); i++) {
                            if (KvizoviAkt.filterKvizovi.get(i).getNaziv().equals(etNaziv.getText().toString()) && KvizoviAkt.filterKvizovi.get(KvizoviAkt.pozicija).getNaziv().equals(etNaziv.getText().toString())) {
                                ima = false;
                            }
                        }
                    }
                    if (!KvizoviAkt.filtrirano2) {
                        for (int i = 0; i < KvizoviAkt.kvizovi.size(); i++) {
                            if (KvizoviAkt.kvizovi.get(i).getNaziv().equals(etNaziv.getText().toString()) && KvizoviAkt.kvizovi.get(KvizoviAkt.pozicija).getNaziv().equals(etNaziv.getText().toString())) {
                                ima = false;
                            }
                        }
                    } else if (KvizoviAkt.filtrirano2) {
                        for (int i = 0; i < KvizoviAkt.filterKvizovi2.size(); i++) {
                            if (KvizoviAkt.filterKvizovi2.get(i).getNaziv().equals(etNaziv.getText().toString()) && KvizoviAkt.filterKvizovi2.get(KvizoviAkt.pozicija).getNaziv().equals(etNaziv.getText().toString())) {
                                ima = false;
                            }
                        }
                    }
                    if (etNaziv.getText().toString().length() == 0 || ima) {
                        etNaziv.setBackgroundColor(Color.RED);
                        ima = false;
                    } else {
                        //validacijaPitanja.clear();
                        etNaziv.setBackgroundColor(Color.WHITE);
                        Kategorija kat = new Kategorija(kategorije.get(spKategorije.getSelectedItemPosition()).getNaziv(), kategorije.get(spKategorije.getSelectedItemPosition()).getId());
                        Kviz kviz = new Kviz(etNaziv.getText().toString(), pitanja, kat);
                        kvizZaBazuEdit = kviz;
                        String idKategorijeZaEdit = "";
                        for(int i = 0; i < KvizoviAkt.pocetneKategorijeIzBaze.size(); i++){
                            if(KvizoviAkt.pocetneKategorijeIzBaze.get(i).second.getNaziv().equals(kvizZaBazuEdit.getKategorija().getNaziv())){
                                idKategorijeZaEdit = KvizoviAkt.pocetneKategorijeIzBaze.get(i).first;
                                break;
                            }
                        }
                        new EditovanjeKvizovaKlasa(new AsyncResponse() {
                            @Override
                            public void processFinish() {
                                adapter.notifyDataSetChanged();
                            }
                        }).execute(idKvizaZaEdit, idKategorijeZaEdit);
                        Intent returnIntent = getIntent();
                        returnIntent.putExtra("nazivKviza", kviz.getNaziv());
                        returnIntent.putExtra("pitanja", kviz.getPitanja());
                        returnIntent.putExtra("kategorija", kviz.getKategorija());
                        setResult(RESULT_OK, returnIntent);
                        finish();
                    }
                }
            }
        });

        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                novaPitanja.clear();
                novi.getPitanja().clear();
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                if (!"text/*".equals(intent.getType())) {
                    ispravnaDatoteka = false;
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                    alertDialog.setTitle("Datoteka kviza kojeg importujete nema ispravan format!");
                    alertDialog.setIcon(R.drawable.error);
                    alertDialog.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                }
                            });
                    alertDialog.show();
                }
                startActivityForResult(intent, 2);
            }
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onClick(View v) {
                // Auto-generated method stub
            }

            @Override
            public void onItemSelected(AdapterView<?> arg0, View view, int position, long arg3) {
                if (position == 0) {
                    // do nothing, ispisuje "Svi"
                } else if (position == kategorije.size() - 1) {
                    Intent myIntent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    DodajKvizAkt.this.startActivityForResult(myIntent, 0);
                } else {
                    //ostale kategorije
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // Auto-generated method stub
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                kategorije.add(kategorije.size() - 1, new Kategorija(data.getStringExtra("nazivKat"), data.getStringExtra("id")));
                KvizoviAkt.kategorije.add(new Kategorija(data.getStringExtra("nazivKat"), data.getStringExtra("id")));
                validacijaKategorija.add(new Kategorija(data.getStringExtra("nazivKat"), data.getStringExtra("id")));
                adapterKategorije.notifyDataSetChanged();
            }
            if (resultCode == RESULT_CANCELED) {
                //Write your code if there's no result
            }

        } else if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                pitanja.add(pitanja.size() - 1, new Pitanje(data.getStringExtra("nazivPitanja"), data.getStringExtra("tekstPitanja"), (ArrayList<String>) data.getSerializableExtra("odgovori"), data.getStringExtra("isTacan")));
                validacijaPitanja.add(new Pitanje(data.getStringExtra("nazivPitanja"), data.getStringExtra("tekstPitanja"), (ArrayList<String>) data.getSerializableExtra("odgovori"), data.getStringExtra("isTacan")));
                adapter.notifyDataSetChanged();
                adapterMoguce.notifyDataSetChanged();
            }
            if (resultCode == RESULT_CANCELED) {
                //Write your code if there's no result
            }
        } else if (requestCode == 2) {
            if (resultCode == RESULT_OK) {
                Uri uri = null;
                if (data != null) {
                    uri = data.getData();
                    ArrayList<String> dat = null;
                    try {
                        dat = readTextFromUri(uri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    assert dat != null;
                    boolean postoji = false;
                    boolean alert = false;
                    boolean sadrzi = false;
                    boolean sadrzi2 = false;
                    if (ispravnaDatoteka) {
                        for (int i = 0; i < dat.size(); i++) {
                            if (i == 0) {
                                int brojac = 0;
                                int pokazivac = 0;
                                for (int j = 0; j < dat.get(i).length(); j++) {
                                    if (dat.get(i).charAt(j) == ',' && brojac == 0) {
                                        String naziv = dat.get(i).substring(pokazivac, j);
                                        for (int k = 0; k < KvizoviAkt.kvizovi.size(); k++) {
                                            if (KvizoviAkt.kvizovi.get(k).getNaziv().equals(naziv)) {
                                                postoji = true;
                                            }
                                        }
                                        if (postoji) {
                                            AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                            alertDialog.setTitle("Kviz kojeg importujete već postoji!");
                                            alertDialog.setIcon(R.drawable.error);
                                            alertDialog.setPositiveButton("OK",
                                                    new DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog, int which) {
                                                            Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                            alertDialog.show();
                                            alert = true;
                                            break;
                                        } else {
                                            novi.setNaziv(naziv);
                                            postoji = false;
                                        }
                                        pokazivac = j + 1;
                                        brojac++;
                                    } else if (dat.get(i).charAt(j) == ',' && brojac == 1) {
                                        if (!postoji) {
                                            String kategorija = dat.get(i).substring(pokazivac, j);
                                            novi.setKategorija(new Kategorija(kategorija));
                                            for (int k = 0; k < kategorije.size(); k++) {
                                                if (kategorije.get(k).getNaziv().equals(kategorija)) {
                                                    sadrzi = true;
                                                }
                                            }
                                            for (int k = 0; k < KvizoviAkt.kategorije.size(); k++) {
                                                if (KvizoviAkt.kategorije.get(k).getNaziv().equals(kategorija)) {
                                                    sadrzi2 = true;
                                                }
                                            }
                                            pokazivac = j + 1;
                                            brojac++;
                                        }
                                    } else if (brojac == 2) {
                                        if (!postoji) {
                                            try {
                                                int brojPitanja = Integer.parseInt(dat.get(i).substring(pokazivac, ++j));
                                                if (brojPitanja != dat.size() - 1) {
                                                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                    alertDialog.setTitle("Kviz kojeg imporujete ima neispravan broj pitanja!");
                                                    alertDialog.setIcon(R.drawable.error);
                                                    alertDialog.setPositiveButton("OK",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                    alertDialog.show();
                                                    alert = true;
                                                    break;
                                                }
                                                brojac++;
                                            } catch (Exception e) {
                                                AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                alertDialog.setTitle("Kviz kojeg imporujete ima neispravan broj pitanja!");
                                                alertDialog.setIcon(R.drawable.error);
                                                alertDialog.setPositiveButton("OK",
                                                        new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialog, int which) {
                                                                Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                            }
                                                        });
                                                alertDialog.show();
                                                alert = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            } else {
                                if (!postoji && !alert) {
                                    int brojac = 0;
                                    int pokazivac = 0;
                                    int brojOdgovora = 0;
                                    int tacanOdg = 0;
                                    Pitanje novoPitanje = new Pitanje();
                                    //novaPitanja = new ArrayList<>();
                                    for (int j = 0; j < dat.get(i).length(); j++) {
                                        if (dat.get(i).charAt(j) == ',' && brojac == 0) {
                                            String pitanje = dat.get(i).substring(pokazivac, j);
                                            novoPitanje.setNaziv(pitanje);
                                            boolean postojiPitanjeUBazi = false;
                                            for(int ima = 0; ima < mogucaPitanja.size(); ima++){
                                                if(mogucaPitanja.get(ima).getNaziv().equals(novoPitanje.getNaziv())){
                                                    postojiPitanjeUBazi = true;
                                                }
                                            }
                                            if(postojiPitanjeUBazi && !alert){
                                                AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                alertDialog.setTitle("Pitanje se vec nalazi u bazi!");
                                                alertDialog.setIcon(R.drawable.error);
                                                alertDialog.setPositiveButton("OK",
                                                        new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialog, int which) {
                                                                Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                            }
                                                        });
                                                alertDialog.show();
                                                alert = true;
                                            } else {
                                                novoPitanje.setTekstPitanja(pitanje);
                                                boolean duploPitanje = false;
                                                for (int s = 0; s < novaPitanja.size(); s++) {
                                                    if (novoPitanje.getNaziv().equals(novaPitanja.get(s).getNaziv())) {
                                                        duploPitanje = true;
                                                    }
                                                }
                                                if (duploPitanje && !alert) {
                                                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                    alertDialog.setTitle("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                                                    alertDialog.setIcon(R.drawable.error);
                                                    alertDialog.setPositiveButton("OK",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                    alertDialog.show();
                                                    alert = true;
                                                } else {
                                                    pokazivac = j + 1;
                                                    brojac++;
                                                }
                                            }
                                        } else if (dat.get(i).charAt(j) == ',' && brojac == 1 && !alert) {
                                            try {
                                                brojOdgovora = Integer.parseInt(dat.get(i).substring(pokazivac, j));
                                                pokazivac = j + 1;
                                                brojac++;
                                            } catch (Exception e) {

                                            }
                                        } else if (dat.get(i).charAt(j) == ',' && brojac == 2 && !alert) {
                                            try {
                                                tacanOdg = Integer.parseInt(dat.get(i).substring(pokazivac, j));
                                                if (tacanOdg < 0 || tacanOdg > brojOdgovora) {
                                                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                    alertDialog.setTitle("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                                                    alertDialog.setIcon(R.drawable.error);
                                                    alertDialog.setPositiveButton("OK",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                    alertDialog.show();
                                                    alert = true;
                                                    break;
                                                }
                                                pokazivac = j + 1;
                                                brojac++;
                                            } catch (Exception e) {
                                                AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                alertDialog.setTitle("Kviz kojeg importujete ima neispravan index tačnog odgovora!");
                                                alertDialog.setIcon(R.drawable.error);
                                                alertDialog.setPositiveButton("OK",
                                                        new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialog, int which) {
                                                                Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                            }
                                                        });
                                                alertDialog.show();
                                                alert = true;
                                                break;
                                            }
                                        } else if (brojac == 3 && !alert) {
                                            boolean dupliOdgovor = false;
                                            if (!alert) {
                                                ArrayList<String> listaOdgovora = new ArrayList<>();
                                                String odg = dat.get(i).substring(pokazivac, dat.get(i).length());
                                                int pok2 = 0;
                                                for (int k = 0; k < odg.length(); k++) {
                                                    if (k == odg.length() - 1) {
                                                        if (listaOdgovora.contains(odg.substring(pok2, odg.length())))
                                                            dupliOdgovor = true;
                                                        listaOdgovora.add(odg.substring(pok2, odg.length()));
                                                    } else {
                                                        if (odg.charAt(k) == ',') {
                                                            if (listaOdgovora.contains(odg.substring(pok2, k)))
                                                                dupliOdgovor = true;
                                                            listaOdgovora.add(odg.substring(pok2, k));
                                                            pok2 = k + 1;
                                                        }
                                                    }
                                                }
                                                if (dupliOdgovor) {
                                                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                    alertDialog.setTitle("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                                                    alertDialog.setIcon(R.drawable.error);
                                                    alertDialog.setPositiveButton("OK",
                                                            new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                    alertDialog.show();
                                                    alert = true;
                                                    break;
                                                } else {
                                                    novoPitanje.setTacan(listaOdgovora.get(tacanOdg));
                                                    novoPitanje.setOdgovori(listaOdgovora);
                                                    novaPitanja.add(novoPitanje);
                                                    novi.setPitanja(novaPitanja);
                                                    if (brojOdgovora != listaOdgovora.size()) {
                                                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKvizAkt.this);
                                                        alertDialog.setTitle("Kviz kojeg importujete ima neispravan broj odgovora!");
                                                        alertDialog.setIcon(R.drawable.error);
                                                        alertDialog.setPositiveButton("OK",
                                                                new DialogInterface.OnClickListener() {
                                                                    public void onClick(DialogInterface dialog, int which) {
                                                                        Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                                                    }
                                                                });
                                                        alertDialog.show();
                                                        alert = true;
                                                        break;
                                                    }
                                                }
                                                brojac++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (!alert) {
                            etNaziv.setText(novi.getNaziv());
                            if (!sadrzi) {
                                kategorije.add(kategorije.size() - 1, novi.getKategorija());
                                new DodajKategorijuIzImporta().execute();
                                adapterKategorije.notifyDataSetChanged();
                                spKategorije.setSelection(kategorije.size() - 2);
                            } else {
                                int poz = 0;
                                for (int i = 0; i < kategorije.size(); i++) {
                                    if (kategorije.get(i).getNaziv().equals(novi.getKategorija().getNaziv())) {
                                        poz = i;
                                    }
                                }
                                if (poz == 0) {
                                    spKategorije.setSelection(kategorije.size() - 2);
                                } else spKategorije.setSelection(poz);
                                sadrzi = false;
                            }
                            if (!sadrzi2) {
                                KvizoviAkt.kategorije.add(novi.getKategorija());
                            } else sadrzi2 = false;
                            //spKategorije.setSelection(kategorije.size() - 2);
                            pitanja.removeAll(pitanja);
                            pitanja.add(new Pitanje("Dodaj pitanje", null, null, null));
                            pitanja.addAll(pitanja.size() - 1, novi.getPitanja());
                            adapter.notifyDataSetChanged();
                            validacijaPitanja.addAll(novi.getPitanja());
                            new DodajPitanjeIzImporta().execute();
                        }
                    }
                }
            }
        }
    }

    private ArrayList<String> readTextFromUri(Uri uri) throws IOException {
        ArrayList<String> redovi = new ArrayList<>();
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            redovi.add(line);
        }
        redovi.remove(redovi.size() - 1);
        return redovi;
    }
}
