package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {
    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajIkonu;
    private Button btnDodajKategoriju;
    private Icon[] ikone;
    private IconDialog iconDialog = new IconDialog();
    private boolean ima = false;

    public class KlasaKategorija extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + etNaziv.getText().toString() + "\"},  \"idIkonice\": {\"integerValue\":\"" + Integer.parseInt(etIkona.getText().toString()) + "\"}}}";
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                InputStream odgovor = connection.getInputStream();
                StringBuilder response = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))
                ) {
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                String rezultat = response.toString();
                JSONObject jo = new JSONObject(rezultat);
                String name = jo.getString("name");
                JSONObject fields = jo.getJSONObject("fields");
                JSONObject stringValue = fields.getJSONObject("naziv");
                String naziv = stringValue.getString("stringValue");
                JSONObject integerValue = fields.getJSONObject("idIkonice");
                int idIkoniceKategorije = integerValue.getInt("integerValue");
                Kategorija trenutnaKategorija = new Kategorija(naziv, String.valueOf(idIkoniceKategorije));
                //KvizoviAkt.kategorije.add(trenutnaKategorija);
                int brojac = 0;
                for (int i = 0; i < name.length(); i++) {
                    if (name.charAt(i) == '/') {
                        brojac++;
                    }
                    if (brojac == 6) {
                        name = name.substring(++i, name.length());
                        break;
                    }
                }
                Pair<String, Kategorija> par = new Pair<String, Kategorija>(name, trenutnaKategorija);
                KvizoviAkt.pocetneKategorijeIzBaze.add(par);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        etIkona = (EditText) findViewById(R.id.etIkona);
        etNaziv.setHint("Naziv kategorije");
        etIkona.setHint("Ikona");
        etIkona.setEnabled(false);
        btnDodajIkonu = (Button) findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = (Button) findViewById(R.id.btnDodajKategoriju);

        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(ikone);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
                etIkona.setEnabled(true);
            }
        });

        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < DodajKvizAkt.validacijaKategorija.size(); i++) {
                    if (DodajKvizAkt.validacijaKategorija.get(i).getNaziv().equals(etNaziv.getText().toString())) {
                        ima = true;
                    }
                }
                /*for (int i = 0; i < KvizoviAkt.kategorije.size(); i++) {
                    if (kategorijeParovi.get(i).second.getNaziv().equals(etNaziv.getText().toString())) {
                        ima = true;
                    }
                }*/
                if (ima) {
                    etNaziv.setBackgroundColor(Color.RED);
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(DodajKategorijuAkt.this);
                    alertDialog.setTitle("Unesena kategorija već postoji!");
                    alertDialog.setIcon(R.drawable.error);
                    alertDialog.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                                }
                            });
                    alertDialog.show();
                    if (etIkona.getText().toString().length() == 0) {
                        etIkona.setBackgroundColor(Color.RED);
                    } else etIkona.setBackgroundColor(Color.WHITE);
                    ima = false;
                } else if (etNaziv.getText().toString().length() == 0 || etIkona.getText().toString().length() == 0) {
                    if (etNaziv.getText().toString().length() == 0) {
                        etNaziv.setBackgroundColor(Color.RED);
                    } else etNaziv.setBackgroundColor(Color.WHITE);
                    if (etIkona.getText().toString().length() == 0) {
                        etIkona.setBackgroundColor(Color.RED);
                    } else etIkona.setBackgroundColor(Color.WHITE);
                } else {
                    new KlasaKategorija().execute();
                    etNaziv.setBackgroundColor(Color.WHITE);
                    etIkona.setBackgroundColor(Color.WHITE);
                    Kategorija kategorija = new Kategorija(etNaziv.getText().toString(), etIkona.getText().toString());
                    Intent returnIntent = getIntent();
                    returnIntent.putExtra("nazivKat", kategorija.getNaziv());
                    returnIntent.putExtra("id", kategorija.getId());
                    setResult(RESULT_OK, returnIntent);
                    finish();
                }
            }
        });
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        ikone = icons;
        etIkona.setText(String.valueOf(ikone[0].getId()));
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
