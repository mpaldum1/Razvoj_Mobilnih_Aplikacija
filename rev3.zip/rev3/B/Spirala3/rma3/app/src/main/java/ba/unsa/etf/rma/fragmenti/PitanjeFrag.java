package ba.unsa.etf.rma.fragmenti;


import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

/**
 * A simple {@link Fragment} subclass.
 */
public class PitanjeFrag extends Fragment {
    Handler handler;
    TextView tekstPitanja;
    ListView odgovoriPitanja;

    Kviz kviz;
    ArrayList<Pitanje> pitanja;
    ArrayList<String> odgovori;

    int brojPitanja = 0;

    odgovorioPitanje odgovorioP;


    public PitanjeFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pitanje, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        tekstPitanja = getView().findViewById(R.id.tekstPitanja);
        odgovoriPitanja = getView().findViewById(R.id.odgovoriPitanja);
        kviz = (Kviz) getArguments().getSerializable("Kviz");
        pitanja = kviz.getPitanja();

        handler = new Handler();
        ucitajPitanje();


        odgovoriPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Boolean pogodioPitanje = false;
                if(pitanja.get(brojPitanja).getOdgovori().get(i).equals(pitanja.get(brojPitanja).getTacan())){
                    odgovoriPitanja.getChildAt(i).setBackgroundColor(getResources().getColor(R.color.zelena));
                    pogodioPitanje = true;
                }
                else{
                    odgovoriPitanja.getChildAt(i).setBackgroundColor(getResources().getColor(R.color.crvena));
                }

                zavrsiPitanje(pogodioPitanje);

            }
        });

    }

    public void ucitajPitanje(){

        if(brojPitanja >= 0 && brojPitanja < pitanja.size()){
            tekstPitanja.setText(pitanja.get(brojPitanja).getNaziv());
            odgovoriPitanja.setAdapter(new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,pitanja.get(brojPitanja).getOdgovori()));
        }
        else{
            tekstPitanja.setText("Kviz je završen!");
            odgovoriPitanja.setAdapter(new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,new ArrayList<String>()));
        }
    }

    public void zavrsiPitanje(final Boolean pogodioPitanje){
        odgovoriPitanja.setEnabled(false);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                odgovoriPitanja.setEnabled(true);
                brojPitanja++;
                ucitajPitanje();

                odgovorioP = (odgovorioPitanje) getActivity();
                odgovorioP.odgovorio(pogodioPitanje);
            }
        },2000);
    }

    public interface odgovorioPitanje{
        public void odgovorio(Boolean x);
    }

}
