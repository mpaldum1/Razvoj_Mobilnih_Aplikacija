package ba.unsa.etf.rma.asyncKlase;

import android.content.Context;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;

public class PatchKviz extends AsyncTask<String, Void, Void> {

    private IPatchKviz pozivatelj;

    public PatchKviz(IPatchKviz p){
        pozivatelj = p;
    }

    @Override
    protected Void doInBackground(String... strings){
        try {
            Context x = DodajKvizAkt.context;
            InputStream is = x.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            String url = "https://firestore.googleapis.com/v1/projects/rma-moj-projekat/databases/(default)/documents/Kvizovi" + strings[0] + "?access_token=";
            URL urlConnection = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection connection = (HttpURLConnection) urlConnection.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("PATCH");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");

            /*
            String doc = "{ \"fields\":{ \"naziv\":{ \"stringValue\" : \"" + strings[0] +"\"},\"indexTacnog\":{ \"integerValue\" : \"" +strings[1] +"\"}," +
                    "\"odgovori\":{\"arrayValue\":{\"values\":[";
            for(int i=2;i<strings.length; i++){
                doc += "{\"stringValue\": \"" +strings[i] +"\"}";
                if(i!= strings.length-1) doc+=",";
            }
            doc +="]}}";
            doc += "}}";
            */
            String doc = "{\"fields\": {\"naziv\": {\"stringValue\": \""+ strings[1] +"\"},\"idKategorije\": {\"stringValue\": \"" + strings[2] +"\"},\"pitanja\": " +
                    "{\"arrayValue\": {\"values\": [";
            for(int i=3;i<strings.length; i++){
                doc += "{\"stringValue\": \"" +strings[i] +"\"}";
                if(i!= strings.length-1) doc+=",";
            }
            doc += "]}}}}";

            try(OutputStream os = connection.getOutputStream()){
                byte[] input = doc.getBytes("utf-8");
                os.write(input,0,input.length);
            }
            int responseCode = connection.getResponseCode();
            if(responseCode == HttpURLConnection.HTTP_OK){
                try{

                }finally {
                    connection.disconnect();
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public interface IPatchKviz{
        public void onPatchKviz();
    }

    @Override
    protected void onPostExecute(Void aVoid){
        super.onPostExecute(aVoid);
        pozivatelj.onPatchKviz();
    }
}
