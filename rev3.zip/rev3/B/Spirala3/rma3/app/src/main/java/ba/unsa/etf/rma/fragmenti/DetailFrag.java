package ba.unsa.etf.rma.fragmenti;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailFrag extends Fragment {
    ArrayList<Kategorija> kategorije;
    ArrayList<Kviz> kvizovi;
    Kategorija kategorija;

    GridView gridKvizovi;

    ArrayList<Kviz> listaKvizovaZaAdapter;

    Kviz univerzalni = new Kviz("Dodaj Kviz",new Kategorija("DodajKviz","DodajKviz666"));

    kliknuoKratko kk;
    kliknuoDugo kd;
    public DetailFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_frag, container, false);
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        gridKvizovi = getView().findViewById(R.id.gridKvizovi);

        kategorije =(ArrayList<Kategorija>) getArguments().getSerializable("Kategorije");
        kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("Kvizovi");
        kategorija = (Kategorija) getArguments().getSerializable("Kategorija");

        listaKvizovaZaAdapter = new ArrayList<>();
        for(int i=0; i<kvizovi.size(); i++){
            if(kvizovi.get(i).getKategorija().getNaziv().equals(kategorija.getNaziv())){
                listaKvizovaZaAdapter.add(kvizovi.get(i));
            }
            else if(kategorija.getNaziv().equals("Svi")){
                listaKvizovaZaAdapter.add(kvizovi.get(i));
            }
        }
        listaKvizovaZaAdapter.add(univerzalni);


        gridKvizovi.setAdapter(new KvizAdapter(getActivity(),R.layout.list_kviz_element,listaKvizovaZaAdapter));

        gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                kk = (kliknuoKratko)getActivity();
                kk.klikKratko(listaKvizovaZaAdapter.get(i));
            }
        });
        gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                kd = (kliknuoDugo) getActivity();
                kd.klikDugo(listaKvizovaZaAdapter.get(i));
                return true;
            }
        });


    }

    public interface kliknuoKratko{
        public void klikKratko(Kviz k);
    }
    public interface kliknuoDugo{
        public void klikDugo(Kviz k);
    }


}
