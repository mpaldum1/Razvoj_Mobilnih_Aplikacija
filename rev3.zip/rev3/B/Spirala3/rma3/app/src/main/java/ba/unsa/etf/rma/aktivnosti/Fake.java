package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class Fake extends AppCompatActivity implements ListaFrag.kliknutaKategorijaFragment, DetailFrag.kliknuoDugo, DetailFrag.kliknuoKratko {


    ArrayList<Kategorija> kategorije;
    ArrayList<Pitanje> pitanja;
    ArrayList<Kviz> kvizovi;

    FragmentManager fragmentManager;

    ArrayList<String> xyz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_550);

        kategorije = (ArrayList<Kategorija>) getIntent().getBundleExtra("Bundle").getSerializable("Kategorije");
        pitanja = (ArrayList<Pitanje>) getIntent().getBundleExtra("Bundle").getSerializable("Pitanja");
        kvizovi = (ArrayList<Kviz>) getIntent().getBundleExtra("Bundle").getSerializable("Kvizovi");

        fragmentManager = getSupportFragmentManager();
        FrameLayout listPlace= (FrameLayout)findViewById(R.id.listPlace);
        if(listPlace != null){
            ListaFrag listaFrag = new ListaFrag();
            Bundle bundle1 = new Bundle();
            xyz = dajSveKategorije(kategorije);
            Log.e("Wat", "Size: " + xyz.size());
            bundle1.putStringArrayList("Kategorije",xyz);
            listaFrag.setArguments(bundle1);
            fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();

        }


    }
    public ArrayList<String> dajSveKategorije(ArrayList<Kategorija> x){
        ArrayList<String> sveKategorije = new ArrayList<>();
        for(int i=0; i<x.size(); i++){
            sveKategorije.add(x.get(i).getNaziv());
        }
        return sveKategorije;
    }

    @Override
    public void kliknuoKategorijuFragment(int i) {
        fragmentManager = getSupportFragmentManager();
        FrameLayout detailPlace = (FrameLayout)findViewById(R.id.detailPlace);
        Bundle argumenti = new Bundle();
        argumenti.putSerializable("Kategorije",kategorije);
        argumenti.putSerializable("Kvizovi",kvizovi);
        argumenti.putSerializable("Kategorija",kategorije.get(i));
        DetailFrag detailFrag = new DetailFrag();
        detailFrag.setArguments(argumenti);
        fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
    }

    @Override
    public void klikDugo(Kviz k) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("Kviz", k);
        bundle.putSerializable("Kategorije",kategorije);
        bundle.putSerializable("Pitanja",pitanja);
        bundle.putSerializable("Kvizovi",kvizovi);
        Intent intent = new Intent();
        intent.putExtra("Bundle",bundle);
        setResult(701,intent);
        finish();
    }

    @Override
    public void klikKratko(Kviz k) {
        if(k.getNaziv().equals("Dodaj Kviz")){
            Bundle bundle = new Bundle();
            bundle.putSerializable("Kviz", k);
            bundle.putSerializable("Kategorije",kategorije);
            bundle.putSerializable("Pitanja",pitanja);
            bundle.putSerializable("Kvizovi",kvizovi);
            Intent intent = new Intent();
            intent.putExtra("Bundle",bundle);
            setResult(701,intent);
            finish();
        }
        else{
            Bundle bundle = new Bundle();
            bundle.putSerializable("Kviz", k);
            bundle.putSerializable("Kategorije",kategorije);
            bundle.putSerializable("Pitanja",pitanja);
            bundle.putSerializable("Kvizovi",kvizovi);
            Intent intent = new Intent();
            intent.putExtra("Bundle",bundle);
            setResult(702,intent);
            finish();
        }
    }
}
