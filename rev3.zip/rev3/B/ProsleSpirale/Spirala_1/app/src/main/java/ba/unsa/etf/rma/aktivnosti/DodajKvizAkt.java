package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity {
    Spinner spKategorije;
    EditText etNaziv;
    ListView lvDodanaPitanja;
    ListView lvMogucaPitanja;
    Button btnDodajKviz;

    Kviz kviz;
    ArrayList<String> sveKategorije;
    ArrayList<Kategorija> kategorije;

    ArrayList<Pitanje> pitanja;
    ArrayList<String> svaPitanja;

    ArrayList<String> pitanjaKviza;
    Boolean novi = true;

    ArrayList<Kviz> kvizovi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        spKategorije = findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);

        kviz = (Kviz) getIntent().getBundleExtra("Bundle").getSerializable("Kviz");
        kvizovi = (ArrayList<Kviz>) getIntent().getBundleExtra("Bundle").getSerializable("Kvizovi");
        kategorije = (ArrayList<Kategorija>) getIntent().getBundleExtra("Bundle").getSerializable("Kategorije");
        sveKategorije = new ArrayList<>();

        pitanja = (ArrayList<Pitanje>) getIntent().getBundleExtra("Bundle").getSerializable("Pitanja");
        svaPitanja = new ArrayList<>();
        for(int i = 0; i<pitanja.size();i++){
            svaPitanja.add(pitanja.get(i).getNaziv());
        }
        pitanjaKviza = new ArrayList<>();
        for(int i = 0; i<kviz.getPitanja().size(); i++){
            pitanjaKviza.add(kviz.getPitanja().get(i).getNaziv());
        }
        pitanjaKviza.add("Dodaj Pitanje");

        if(!kviz.getNaziv().equals("Dodaj Kviz")){
            etNaziv.setFocusable(false);
            etNaziv.setText(kviz.getNaziv());
            novi = false;
        }
        postaviSpinnerAdapter();
        postaviAdaptere();

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i == pitanjaKviza.size()-1){
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kvizovi", kvizovi);
                    bundle.putSerializable("Pitanja",pitanja);
                    bundle.putSerializable("Kategorije",kategorije);
                    bundle.putSerializable("Kviz", kviz);
                    Intent intent = new Intent(DodajKvizAkt.this,DodajPitanjeAkt.class);
                    intent.putExtra("Bundle",bundle);
                    startActivityForResult(intent,203);
                }
                else{
                    String temp = pitanjaKviza.get(i);
                    pitanjaKviza.remove(i);
                    svaPitanja.add(temp);
                    postaviAdaptere();
                }
            }
        });
        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String temp = svaPitanja.get(i);
                svaPitanja.remove(i);
                pitanjaKviza.add(0,temp);
                postaviAdaptere();
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(novi){
                    Boolean mozeMoze = true;
                    String x = etNaziv.getText().toString();


                    if(x.trim().equals("") || x == null){
                        etNaziv.setBackgroundColor(getResources().getColor(R.color.boja));
                        mozeMoze = false;
                    }
                    else{
                        etNaziv.setBackgroundColor(Color.WHITE);
                    }


                    if(pitanjaKviza.size() == 1){
                        lvDodanaPitanja.setBackgroundColor(getResources().getColor(R.color.boja));
                        mozeMoze = false;
                    }
                    else{
                        lvDodanaPitanja.setBackgroundColor(Color.WHITE);
                    }

                    for(int i = 0; i<kvizovi.size(); i++){
                        if(kvizovi.get(i).getNaziv().equals(x.trim())){
                            mozeMoze = false;
                            etNaziv.setBackgroundColor(getResources().getColor(R.color.boja));
                            break;
                        }
                    }
                    String y = spKategorije.getSelectedItem().toString();
                    if(y.equals("X Molimo izaberite kategoriju X")){
                        mozeMoze = false;
                        spKategorije.setBackgroundColor(getResources().getColor(R.color.boja));
                    }
                    else{
                        spKategorije.setBackgroundColor(Color.LTGRAY);
                    }
                    if(mozeMoze){
                        Kategorija trazimikategoriju = dajKategoriju(y);
                        ArrayList<Pitanje> trazimilistupitanja = dajPitanjaList();
                        if(!trazimikategoriju.getNaziv().equals("Greska")){
                            Kviz noviNovi = new Kviz(x,trazimilistupitanja,trazimikategoriju);
                            kvizovi.add(noviNovi);
                            kviz = noviNovi;
                            Intent intent = dajIntent();
                            setResult(201, intent);
                            finish();
                        }
                    }
                }
                else{
                    if(pitanjaKviza.size() == 1){
                        lvDodanaPitanja.setBackgroundColor(getResources().getColor(R.color.boja));
                    }
                    else{
                        lvDodanaPitanja.setBackgroundColor(Color.WHITE);
                        String y = spKategorije.getSelectedItem().toString();
                        if(y.equals("X Molimo izaberite kategoriju X")){
                            spKategorije.setBackgroundColor(getResources().getColor(R.color.boja));
                        }
                        else{
                            spKategorije.setBackgroundColor(Color.LTGRAY);
                            Kategorija trazimikategoriju = dajKategoriju(y);
                            ArrayList<Pitanje> trazimilistupitanja = dajPitanjaList();

                            int indexItema = -1;
                            for(int i=0;i<kvizovi.size();i++){
                                if(kvizovi.get(i).getNaziv().equals(kviz.getNaziv())) indexItema = i;
                            }

                            if(indexItema != -1 && !trazimikategoriju.equals("Greska")){
                                kvizovi.get(indexItema).setKategorija(trazimikategoriju);
                                kvizovi.get(indexItema).setPitanja(trazimilistupitanja);
                                Intent intent = dajIntent();
                                setResult(201, intent);
                                finish();

                            }
                        }
                    }
                }
            }
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i == sveKategorije.size()-1){
                    spKategorije.setSelection(0);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kvizovi", kvizovi);
                    bundle.putSerializable("Pitanja",pitanja);
                    bundle.putSerializable("Kategorije",kategorije);
                    bundle.putSerializable("Kviz",kviz);
                    Intent intent = new Intent(DodajKvizAkt.this,DodajKategorijuAkt.class);
                    intent.putExtra("Bundle",bundle);
                    startActivityForResult(intent,204);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void postaviSpinnerAdapter(){
        sveKategorije = new ArrayList<>();
        sveKategorije.add("X Molimo izaberite kategoriju X");
        int postaviNaOvaj = -1;
        for(int i=1; i<kategorije.size(); i++){
            sveKategorije.add(kategorije.get(i).getNaziv());
            if(kviz.getKategorija().getNaziv().equals(kategorije.get(i).getNaziv())) postaviNaOvaj = i;
        }
        sveKategorije.add("Dodaj Kategoriju");
        spKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,sveKategorije));
        if(!novi && postaviNaOvaj != -1)spKategorije.setSelection(postaviNaOvaj);
    }
    public void postaviAdaptere(){
        /*
        sveKategorije = new ArrayList<>();
        int postaviNaOvaj = -1;
        for(int i=1; i<kategorije.size(); i++){
            sveKategorije.add(kategorije.get(i).getNaziv());
            if(kviz.getKategorija().getNaziv().equals(kategorije.get(i).getNaziv())) postaviNaOvaj = i - 1;
        }
        sveKategorije.add("Dodaj Kategoriju");
        spKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,sveKategorije));
        if(!novi && postaviNaOvaj != -1)spKategorije.setSelection(postaviNaOvaj);
        */

        for(int i=0;i<svaPitanja.size(); i++){
            for(int j=0; j<pitanjaKviza.size();j++){
                if(svaPitanja.get(i).equals(pitanjaKviza.get(j))){
                    svaPitanja.set(i,"123456789X");
                }
            }
        }
        for(int i=0;i<svaPitanja.size();i++){
            if(svaPitanja.get(i).equals("123456789X")){
                svaPitanja.remove(i);
                i--;
            }
        }
        lvDodanaPitanja.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,pitanjaKviza));
        lvMogucaPitanja.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,svaPitanja));

    }

    public Kategorija dajKategoriju(String y){
        Kategorija trazimikategoriju = new Kategorija("Greska","Greska");
        for(int i=0;i<kategorije.size();i++){
            if(kategorije.get(i).getNaziv().equals(y)){
                trazimikategoriju = kategorije.get(i);
            }
        }
        return trazimikategoriju;
    }

    public ArrayList<Pitanje> dajPitanjaList(){
        ArrayList<Pitanje> trazimilistupitanja = new ArrayList<>();
        for(int i=0;i<pitanjaKviza.size()-1;i++){
            for(int j=0; j<pitanja.size(); j++){
                if(pitanja.get(j).getNaziv().equals(pitanjaKviza.get(i))){
                    trazimilistupitanja.add(pitanja.get(j));
                }
            }
        }
        return trazimilistupitanja;
    }
    public Intent dajIntent(){
        Bundle bundle = new Bundle();
        bundle.putSerializable("Kvizovi", kvizovi);
        bundle.putSerializable("Pitanja",pitanja);
        bundle.putSerializable("Kategorije",kategorije);
        bundle.putSerializable("Kviz",kviz);
        Intent intent = new Intent();
        intent.putExtra("Bundle",bundle);
        return intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 203){
            if(resultCode == 302){
                kvizovi = (ArrayList<Kviz>) data.getBundleExtra("Bundle").getSerializable("Kvizovi");
                kviz = (Kviz) data.getBundleExtra("Bundle").getSerializable("Kviz");
                pitanja = (ArrayList<Pitanje>) data.getBundleExtra("Bundle").getSerializable("Pitanja");
                svaPitanja.add(pitanja.get(pitanja.size()-1).getNaziv());
                pitanjaKviza.remove(pitanjaKviza.size()-1);
                pitanjaKviza.add(pitanja.get(pitanja.size()-1).getNaziv());
                pitanjaKviza.add("Dodaj Pitanje");
                postaviAdaptere();
            }
        }
        if(requestCode == 204){
            if(resultCode == 402){
                kategorije = (ArrayList<Kategorija>) data.getBundleExtra("Bundle").getSerializable("Kategorije");
                postaviSpinnerAdapter();
            }
        }
    }
}
