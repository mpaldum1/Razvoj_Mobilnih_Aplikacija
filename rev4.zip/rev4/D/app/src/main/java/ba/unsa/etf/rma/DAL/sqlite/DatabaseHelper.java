package ba.unsa.etf.rma.DAL.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// FIXME: 6/17/19 ID se ne ucitava u cursor!!!! prepravi citavu bazu =)

public class DatabaseHelper extends SQLiteOpenHelper{
    public static final String DATABASE_NAME = "QuizBase";
    public static final String TABLE_KATEGORIJE = "Kategorije";
    public static final String TABLE_ODGOVORI = "Odgovori";
    public static final String TABLE_PITANJA = "Pitanja";
    public static final String TABLE_KVIZOVI = "Kvizovi";
    public static final String TABLE_PITANJA_KVIZA = "PitanjaKvizova";
    public static final String TABLE_RANGOVI = "Rangovi";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(getCreateKategorijeTableString());
        db.execSQL(getCreatePitanjaTableString());
        db.execSQL(getCreateOdgovoriTableString());
        db.execSQL(getCreateKvizoviTableString());
        db.execSQL(getCreatePitanjaKvizaTableString());
        db.execSQL(getCreateRangoviTableString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(dropQuery(TABLE_RANGOVI));
        db.execSQL(dropQuery(TABLE_PITANJA_KVIZA));
        db.execSQL(dropQuery(TABLE_KVIZOVI));
        db.execSQL(dropQuery(TABLE_ODGOVORI));
        db.execSQL(dropQuery(TABLE_PITANJA));
        db.execSQL(dropQuery(TABLE_KATEGORIJE));
        onCreate(db);
    }

    private String dropQuery(String tableName) {
        return "drop table if exists " + tableName;
    }

    private String getCreateTableString(String tableName, String[] colsAndProps) {
        String query = "create table " + tableName + "(";

        for(int i = 0; i < colsAndProps.length; i++) {
            query += colsAndProps[i];
            if(i < colsAndProps.length - 1)
                query += ",";
        }

        query += ");";
        return query;
    }

    private String getCreateKategorijeTableString() {
        return getCreateTableString(TABLE_KATEGORIJE, new String[] {
                "id integer primary key",
                "naziv text not null unique",
                "idIkonice integer not null default 0"
        });
    }

    private String getCreatePitanjaTableString() {
        return getCreateTableString(TABLE_PITANJA, new String[] {
                "id integer primary key",
                "naziv text not null unique",
                "idTacnog integer not null"
        });
    }

    private String getCreateOdgovoriTableString() {
        return getCreateTableString(TABLE_ODGOVORI, new String[] {
                "id integer primary key",
                "tekst text not null",
                "idPitanja text references " + TABLE_PITANJA + "(id)"
        });
    }

    private String getCreateKvizoviTableString() {
        return getCreateTableString(TABLE_KVIZOVI, new String[] {
                "id integer primary key",
                "naziv text not null unique",
                "idKategorije text references " + TABLE_KATEGORIJE + "(id)"
        });
    }

    private String getCreatePitanjaKvizaTableString() {
        return getCreateTableString(TABLE_PITANJA_KVIZA, new String[] {
                "idKviza text references " + TABLE_KVIZOVI + "(id)",
                "idPitanja text references " + TABLE_PITANJA + "(id)",
                "primary key(idKviza, idPitanja)"
        });
    }

    private String getCreateRangoviTableString() {
        return getCreateTableString(TABLE_RANGOVI, new String[] {
                "id integer primary key",
                "idKviza text references " + TABLE_KVIZOVI + "(id)",
                "nazivIgraca text not null",
                "procenatTacnih real not null default 0"
        });
    }

}
