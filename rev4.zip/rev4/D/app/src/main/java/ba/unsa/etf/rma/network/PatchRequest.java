package ba.unsa.etf.rma.network;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

public class PatchRequest extends AsyncTask<URL, Void, JSONObject> {
    private JsonHandler method;
    private JSONObject result;
    private String body;

    public PatchRequest(JsonHandler method, String body) {
        this.method = method;
        this.body = body;
    }

    @Override
    protected JSONObject doInBackground(URL... urls) {
        URL url = urls[0];
        String json = "{\"message\":\"";
        HttpsURLConnection connection = null;

        try {
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("PATCH");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);

            OutputStream os = connection.getOutputStream();
            byte[] input = body.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);

            json += connection.getResponseCode() + ": " + connection.getResponseMessage() + "\"},";
            json += "";

            result = new JSONObject(json);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if(connection != null)
                connection.disconnect();
        }

        return result;
    }

    @Override
    protected void onPostExecute(JSONObject json) {
        super.onPostExecute(json);
        method.execute(result);
    }
}
