package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;

public class ListaFrag extends Fragment {
    private ListView listaKategorija;

    private KvizoviAkt activity;
    private ArrayAdapter<Kategorija> kategorijaAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.lista_frag, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        listaKategorija = view.findViewById(R.id.listaKategorija);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        activity = (KvizoviAkt) getActivity();

        ArrayList<Kategorija> kategorije = activity.getKategorije();
        kategorijaAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, kategorije);
        listaKategorija.setAdapter(kategorijaAdapter);

        listaKategorija.setOnItemClickListener((parent, view, position, id) -> {
            Kategorija kategorija = kategorijaAdapter.getItem(position);
            activity.setTrenutnaKategorija(kategorija);
        });
    }

    public void notifyAdapter() {
        kategorijaAdapter.notifyDataSetChanged();
    }
}
