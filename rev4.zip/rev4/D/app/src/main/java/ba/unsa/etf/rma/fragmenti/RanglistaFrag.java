package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Rang;
import ba.unsa.etf.rma.klase.Ranglista;

public class RanglistaFrag extends Fragment {
    private ListView ranglistaView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.ranglista_frag, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ranglistaView = view.findViewById(R.id.ranglista);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Ranglista ranglista = (Ranglista) getArguments().getSerializable("ranglista");
        ArrayAdapter<Rang> ranglistAdapter = new ArrayAdapter<Rang>(getActivity(), android.R.layout.simple_list_item_1, ranglista.getRanglista());
        ranglistaView.setAdapter(ranglistAdapter);
    }
}
