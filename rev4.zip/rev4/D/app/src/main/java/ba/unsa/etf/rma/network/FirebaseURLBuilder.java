package ba.unsa.etf.rma.network;

import java.net.MalformedURLException;
import java.net.URL;

public class FirebaseURLBuilder {
    private static final String projectUrl = "https://firestore.googleapis.com/v1/projects/rmaprojekat-d780c/databases/(default)/documents";

    public static URL getUrl(String collection) {
        String url = projectUrl + "/" + collection + accessTokenQuery();
        return urlFromString(url);
    }

    public static URL getUrl(String collection, String document) {
        String url = projectUrl + "/" + collection + "/" + document + accessTokenQuery();
        return urlFromString(url);
    }

    public static URL getQueryUrl() {
        String url = projectUrl + ":runQuery" + accessTokenQuery();
        return urlFromString(url);
    }

    private static URL urlFromString(String url) {
        try {
            return new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String accessTokenQuery() {
        return "?access_token=" + Authentication.getToken();
    }
}
