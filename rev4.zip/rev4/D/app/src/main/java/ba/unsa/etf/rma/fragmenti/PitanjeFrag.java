package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeFrag extends Fragment {
    private ListView lvOdgovori;
    private TextView nazivPitanja;

    private IgrajKvizAkt activity;
    private ArrayAdapter playAdapter;
    private Pitanje trenutnoPitanje;
    private boolean odgovoreno = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pitanje_frag, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        nazivPitanja = view.findViewById(R.id.tekstPitanja);
        lvOdgovori = view.findViewById(R.id.odgovoriPitanja);

        activity = (IgrajKvizAkt) getActivity();
        trenutnoPitanje = (Pitanje) getArguments().getSerializable("pitanje");
        ArrayList<String> odgovori = trenutnoPitanje.dajRandomOdgovore();

        nazivPitanja.setText(trenutnoPitanje.getTekstPitanja());
        playAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, odgovori);
        lvOdgovori.setAdapter(playAdapter);

        lvOdgovori.setOnItemClickListener((parent, vw, position, id) -> {
            if(odgovoreno)
                return;
            odgovoreno = true;

            String selected = odgovori.get(position);
            int tacanIdx = odgovori.indexOf(trenutnoPitanje.getTacan());

            boolean tacan = selected.equals(trenutnoPitanje.getTacan());

            if(tacan) {
                vw.setBackgroundColor(getResources().getColor(R.color.zelena));
            }else {
                vw.setBackgroundColor(getResources().getColor(R.color.crvena));
                int firstVisibleIdx = lvOdgovori.getFirstVisiblePosition();
                int visibilityDif = tacanIdx - firstVisibleIdx;
                if(visibilityDif >= 0 && visibilityDif < lvOdgovori.getChildCount()) {
                    View tacanView = lvOdgovori.getChildAt(tacanIdx - firstVisibleIdx);
                    tacanView.setBackgroundColor(getResources().getColor(R.color.zelena));
                }
            }

            activity.answerQuestion(tacan);
        });
    }


}
