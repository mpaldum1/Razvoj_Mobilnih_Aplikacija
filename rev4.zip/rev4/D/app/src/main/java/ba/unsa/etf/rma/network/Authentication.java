package ba.unsa.etf.rma.network;

import android.app.Activity;
import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;

import ba.unsa.etf.rma.R;

public class Authentication extends AsyncTask<Void, Void, Void> {
    private WeakReference<Activity> activity;
    private JsonHandler method;
    private static JSONObject result;

    public Authentication(Activity activity, JsonHandler method) {
        this.activity = new WeakReference<>(activity);
        this.method = method;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            InputStream is = activity.get().getResources().openRawResource(R.raw.firebaseauth);
            GoogleCredential credentials;
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            result = new JSONObject("{\"token\":\"" + token + "\"}");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        method.execute(result);
    }

    public static String getToken() {
        try {
            return result.getString("token");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "notoken";
    }
}
