package ba.unsa.etf.rma.DAL.firebase;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.network.DeleteRequest;
import ba.unsa.etf.rma.network.FirebaseURLBuilder;
import ba.unsa.etf.rma.network.GetRequest;
import ba.unsa.etf.rma.network.PatchRequest;
import ba.unsa.etf.rma.network.PostRequest;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.network.JsonHandler;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizDAO implements DAO<Kviz>, JsonToObjectFactory<Kviz>, ObjectToJsonFactory<Kviz> {
    private static KvizDAO instance;
    private final String COLLECTION = "Kvizovi";
    
    private KvizDAO() {}
    
    public static KvizDAO getInstance() {
        if(instance == null)
            instance = new KvizDAO();
        return instance;
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Kviz>> resultHandler) {
        KategorijaDAO.getInstance().getAll(kateogrije -> {
            ArrayList<Kviz> kvizovi = new ArrayList<>();
            for(Kategorija kategorija : kateogrije) {
                getAllByCategoryId(kategorija.getNaziv(), kvizovi::addAll);
            }
            resultHandler.execute(kvizovi);
        });
    }

    public void getAllByCategoryId(String categoryId, ResultHandler<ArrayList<Kviz>> resultHandler) {
//        if(categoryId.equals(KvizoviAkt.kategorijaSvi.getNaziv())) {
//            getAll(resultHandler);
//            return;
//        }

        String structuredQueryId = "{\n" +
                " \"structuredQuery\": {\n" +
                "  \"where\": {\n" +
                "   \"fieldFilter\": {\n" +
                "    \"field\": {\n" +
                "     \"fieldPath\": \"idKategorije\"\n" +
                "    },\n" +
                "    \"op\": \"EQUAL\",\n" +
                "    \"value\": {\n" +
                "     \"stringValue\": \""+categoryId+"\"\n" +
                "    }\n" +
                "   }\n" +
                "  },\n" +
                "  \"from\": [\n" +
                "   {\n" +
                "    \"collectionId\": \"Kvizovi\"\n" +
                "   }\n" +
                "  ]\n" +
                " }\n" +
                "}";

        String stucturedQueryAll = "{\n" +
                " \"structuredQuery\": {\n" +
                "  \"from\": [\n" +
                "   {\n" +
                "    \"collectionId\": \"Kvizovi\"\n" +
                "   }\n" +
                "  ]\n" +
                " }\n" +
                "}";

        String structuredQuery = categoryId.equals(KvizoviAkt.kategorijaSvi.getNaziv()) ? stucturedQueryAll : structuredQueryId;

        KategorijaDAO.getInstance().get(categoryId, kategorija -> {
            if(kategorija == null)
                kategorija = KvizoviAkt.kategorijaSvi;

            Kategorija finalKategorija = kategorija;
            new PostRequest(json -> {
                ArrayList<Kviz> list = new ArrayList<>();
                try {
                    if(json == null)
                        return;
                    JSONArray documents = json.getJSONArray("documents");
                    addKvizToList(finalKategorija, documents, list, 0);
                    resultHandler.execute(list);
                } catch (JSONException e) {
                    Log.e("Failed query", "Something is wrong with the json object in Kviz query");
                    e.printStackTrace();
                }
            }, structuredQuery).execute(FirebaseURLBuilder.getQueryUrl());
        });
    }

    private void addKvizToList(Kategorija kategorija, JSONArray documents, ArrayList<Kviz> list, int i) {
        if(i >= documents.length())
            return;

        try {
            JSONObject item = documents.getJSONObject(i);
            JSONObject document = item.getJSONObject("document");
            JSONObject fields = document.getJSONObject("fields");

            final int fini = i + 1;
            jsonToObjectNameOnly(fields, kategorija, result -> {
                list.add(result);
                addKvizToList(kategorija, documents, list, fini);
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void get(String id, ResultHandler<Kviz> resultHandler) {
        new GetRequest(json -> {
            try {
                if(json != null) {
                    JSONObject fields = json.getJSONObject("fields");
                    jsonToObject(fields, resultHandler);
                }else {
                    resultHandler.execute(null);
                }
            } catch (JSONException e) {
                Log.e("JSON Error", "Could not find 'fields'");
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION, id));
    }

    @Override
    public void add(Kviz object, JsonHandler responseHandler) {
        objectToJson(object, result -> new PatchRequest(responseHandler, String.valueOf(result))
                .execute(FirebaseURLBuilder.getUrl(COLLECTION, object.getNaziv())));
    }

    @Override
    public void update(Kviz object, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {
        new DeleteRequest(responseHandler).
                execute(FirebaseURLBuilder.getUrl(COLLECTION, id));
    }

    @Override
    public void jsonToObject(JSONObject json, ResultHandler<Kviz> handler) {
        Kviz kviz = new Kviz("kviz", KvizoviAkt.kategorijaSvi, new ArrayList<>());

        try {
            String naziv = json.getJSONObject("naziv").getString("stringValue");
            String kategId = json.getJSONObject("idKategorije").getString("stringValue");
            kviz.setNaziv(naziv);

            loadPitanjatoKviz(json, kviz, result -> {
                if(!kategId.equals("Svi"))
                    KategorijaDAO.getInstance().get(kategId, kategorija ->{
                        kviz.setKategorija(kategorija);
                        handler.execute(kviz);
                    });
                else
                    handler.execute(kviz);
            });
        } catch (JSONException e) {
            Log.e("Failed Kviz", e.getMessage());
            handler.execute(null);
        }
    }

    private void jsonToObjectNameOnly(JSONObject json, Kategorija kategorija, ResultHandler<Kviz> handler) {
        Kviz kviz = new Kviz("kviz", KvizoviAkt.kategorijaSvi, null);

        try {
            String naziv = json.getJSONObject("naziv").getString("stringValue");
            kviz.setNaziv(naziv);
            kviz.setKategorija(kategorija);
            handler.execute(kviz);
        } catch (JSONException e) {
            Log.e("Failed Kviz", e.getMessage());
            handler.execute(null);
        }
    }

    private void loadPitanjatoKviz(JSONObject json, Kviz kviz, ResultHandler<Kviz> result) {
        try{
            JSONArray pitanjaJson = json.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
            Pitanje dummy = new Pitanje();

            PitanjeDAO.getInstance().getAll(svaPitanja -> {
                for(int i = 0; i < pitanjaJson.length(); i++) {
                    try {
                        String naziv = pitanjaJson.getJSONObject(i).getString("stringValue");
                        dummy.setNaziv(naziv);
                        int index = svaPitanja.indexOf(dummy);
                        Pitanje pitanje = null;
                        if(index != -1)
                            pitanje = svaPitanja.get(index);
                        if(pitanje != null) {
                            kviz.getPitanja().add(pitanje);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                result.execute(kviz);
            });
        }catch(JSONException e) {
            Log.e("Kviz", "Nema pitanja");
        }
    }

    @Override
    public void objectToJson(Kviz object, JsonHandler handler) {
        String naziv = object.getNaziv();
        String idKategorije = object.getKategorija().getNaziv();
        String pitanja = "";

        for(int i = 0; i < object.getPitanja().size(); i++) {
            pitanja += "{\"stringValue\":\"" + object.getPitanja().get(i).getNaziv() + "\"}";
            if(i < object.getPitanja().size() - 1)
                pitanja += ",";
        }

        String json = "{\"fields\": {\n" +
                "  \"naziv\": {\n" +
                "   \"stringValue\": \"" + naziv + "\"\n" +
                "  },\n" +
                "  \"idKategorije\": {\n" +
                "   \"stringValue\": \"" + idKategorije + "\"\n" +
                "  },\n" +
                "  \"pitanja\": {\n" +
                "   \"arrayValue\": {\n" +
                "    \"values\": [\n" +
                pitanja +
                "    ]\n" +
                "   }\n" +
                "  }\n" +
                " }}";

        try {
            JSONObject fields = new JSONObject(json);
            handler.execute(fields);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
