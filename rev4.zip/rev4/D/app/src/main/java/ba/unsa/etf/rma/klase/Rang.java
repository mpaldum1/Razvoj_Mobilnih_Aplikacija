package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Rang implements Serializable, Comparable<Rang> {
    private int rang;
    private String imeIgraca;
    private double procenatTacnih;

    public Rang() {
        this(0, "", 0);
    }

    public Rang(int rang, String imeIgraca, double procenatTacnih) {
        this.rang = rang;
        this.imeIgraca = imeIgraca;
        this.procenatTacnih = procenatTacnih;
    }

    @Override
    public String toString() {
        return rang + ". " + imeIgraca + " - " + procenatTacnih;
    }

    public int getRang() {
        return rang;
    }

    public void setRang(int rang) {
        this.rang = rang;
    }

    public String getImeIgraca() {
        return imeIgraca;
    }

    public void setImeIgraca(String imeIgraca) {
        this.imeIgraca = imeIgraca;
    }

    public double getProcenatTacnih() {
        return procenatTacnih;
    }

    public void setProcenatTacnih(double procenatTacnih) {
        this.procenatTacnih = procenatTacnih;
    }

    @Override
    public int compareTo(Rang o) {
        if(getProcenatTacnih() < o.getProcenatTacnih())
            return 1;
        if(getProcenatTacnih() > o.getProcenatTacnih())
            return -1;

        return 0;
    }
}
