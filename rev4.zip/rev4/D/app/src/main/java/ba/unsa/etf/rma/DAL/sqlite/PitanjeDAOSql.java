package ba.unsa.etf.rma.DAL.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeDAOSql {
    private final SQLiteDatabase db;

    public PitanjeDAOSql(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    public ArrayList<Pitanje> loadPitanjaKviza(Kviz kviz) {
        ArrayList<Pitanje> pitanja = new ArrayList<>();

        String query = "select p.id, p.idTacnog from "
                + DatabaseHelper.TABLE_PITANJA + " p, "
                + DatabaseHelper.TABLE_PITANJA_KVIZA + " pk "
                + "where pk.idKviza = ? and p.id = pk.idPitanja;";

        String[] args = new String[] {kviz.getNaziv()};
        Cursor cursor = db.rawQuery(query, args);

        while (cursor.moveToNext()) {
            pitanja.add(getPitanjeFromCursor(cursor));
        }

        cursor.close();
        return pitanja;
    }

    private Pitanje getPitanjeFromCursor(Cursor cursor) {
        if(cursor == null || cursor.getCount() == 0)
            return null;

        Pitanje pitanje = new Pitanje();

        String naziv = cursor.getColumnName(cursor.getColumnIndexOrThrow("id"));
        int idTacnog = cursor.getInt(cursor.getColumnIndexOrThrow("idTacnog"));
        ArrayList<String> odgovori = getOdgovori(pitanje);

        pitanje.setNaziv(naziv);
        pitanje.setTekstPitanja(naziv);
        pitanje.setOdgovori(odgovori);
        pitanje.setTacan(odgovori.get(idTacnog));

        return pitanje;
    }

    private ArrayList<String> getOdgovori(Pitanje pitanje) {
        ArrayList<String> odgovori = new ArrayList<>();

        String selection = "pitanjeId = ?";
        String[] args = new String[] {pitanje.getNaziv()};
        Cursor cursor = db.query(DatabaseHelper.TABLE_ODGOVORI, null, selection, args, null, null, null);

        while (cursor.moveToNext()) {
            String odgovor = cursor.getString(cursor.getColumnIndexOrThrow("text"));
            odgovori.add(odgovor);
        }

        cursor.close();
        return odgovori;
    }

    public void addPitanjeToKviz(Pitanje pitanje, Kviz kviz) {
        ContentValues pitanjeValues = new ContentValues();
        pitanjeValues.putNull("id");
        pitanjeValues.put("id", pitanje.getNaziv());
        pitanjeValues.put("idTacnog", pitanje.getOdgovori().indexOf(pitanje.getTacan()));
        db.insert(DatabaseHelper.TABLE_PITANJA, null, pitanjeValues);

        try {
            ContentValues bindValues = new ContentValues();
            bindValues.putNull("id");
            bindValues.put("idKviza", kviz.getNaziv());
            bindValues.put("idPitanja", pitanje.getNaziv());
            db.insertOrThrow(DatabaseHelper.TABLE_PITANJA_KVIZA, null, bindValues);
        }catch (SQLiteException e) {
            //
        }

        for(String odg : pitanje.getOdgovori()) {
            ContentValues odgValues = new ContentValues();
            odgValues.putNull("id");
            odgValues.put("tekst", odg);
            odgValues.put("idPitanja", pitanje.getNaziv());
            db.insert(DatabaseHelper.TABLE_ODGOVORI, null, odgValues);
        }
    }
}
