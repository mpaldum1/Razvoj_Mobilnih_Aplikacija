package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

import ba.unsa.etf.rma.R;


public class OdgovoriAdapter extends ArrayAdapter<String> {
    private int resource;
    private String tacanOdgovor;

    public OdgovoriAdapter(Context context, int resource, List<String> objects) {
        super(context, resource, objects);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);

        String odgovor = getItem(position);

        if(odgovor.equals(tacanOdgovor)) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.tacanOdgovor));
        }else {
            view.setBackgroundColor(getContext().getResources().getColor(android.R.color.transparent));
        }

        return view;
    }

    public void add(String object, boolean tacan) {
        super.add(object);
        if(tacan && tacanOdgovor == null) {
            tacanOdgovor = object + "";
        }
    }

    @Override
    public void remove(String object) {
        super.remove(object);
        if(object.equals(tacanOdgovor)) {
            tacanOdgovor = null;
        }
    }
}
