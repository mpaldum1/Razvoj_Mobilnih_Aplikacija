package ba.unsa.etf.rma.network;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class DeleteRequest extends AsyncTask<URL, Void, JSONObject> {
    private JsonHandler method;
    private JSONObject result;

    public DeleteRequest(JsonHandler method) {
        this.method = method;
    }

    @Override
    protected JSONObject doInBackground(URL... urls) {
        URL url = urls[0];
        String json = "{\"message\":\"";
        HttpsURLConnection connection = null;

        try {
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("DELETE");

            json += connection.getResponseCode() + ": " + connection.getResponseMessage() + "\"}";

            result = new JSONObject(json);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if(connection != null)
                connection.disconnect();
        }

        return result;
    }

    @Override
    protected void onPostExecute(JSONObject json) {
        super.onPostExecute(json);
        method.execute(result);
    }
}
