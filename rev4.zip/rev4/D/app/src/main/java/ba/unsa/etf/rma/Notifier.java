package ba.unsa.etf.rma;

import android.app.AlertDialog;
import android.content.Context;

public class Notifier {
    private Notifier() {}

    public static void displayAlert(Context context, String message) {
        new AlertDialog.Builder(context)
                .setTitle("Greska")
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }
}
