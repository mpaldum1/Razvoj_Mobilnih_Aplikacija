package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.firebase.PitanjeDAO;
import ba.unsa.etf.rma.adapteri.OdgovoriAdapter;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    private EditText etNaziv;
    private ListView lvOdgovori;
    private EditText etOdgovor;
    private Button btnDodajOdgovor;
    private Button btnDodajTacan;
    private Button btnDodajPitanje;

    private String tacanOdgovor;
    private ArrayList<String> odgovori;
    private OdgovoriAdapter odgovoriAdapter;

    private Drawable editTextBackground;

    private final PitanjeDAO pitanjeDAO = PitanjeDAO.getInstance();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_pitanje_akt);

        etNaziv = findViewById(R.id.etNaziv);
        lvOdgovori = findViewById(R.id.lvOdgovori);
        etOdgovor = findViewById(R.id.etOdgovor);
        btnDodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        btnDodajTacan = findViewById(R.id.btnDodajTacan);
        btnDodajPitanje = findViewById(R.id.btnDodajPitanje);

        editTextBackground = etNaziv.getBackground();

        odgovori = new ArrayList<>();

        setUpOdgovoriAdapter();
        setUpAddingAnswer();
        setUpRemovingAnswer();

        setUpOnQuestionComplete();
    }

    private void setUpOdgovoriAdapter() {
        odgovoriAdapter = new OdgovoriAdapter(this, android.R.layout.simple_list_item_1, odgovori);
        lvOdgovori.setAdapter(odgovoriAdapter);
    }

    private void setUpAddingAnswer() {
        btnDodajOdgovor.setOnClickListener(view -> {
            addAnswer(false);
        });

        btnDodajTacan.setOnClickListener(view -> {
            addAnswer(true);
        });
    }

    private void addAnswer(boolean tacan) {
        String odgovor = etOdgovor.getText().toString().trim();

        if (odgovor.isEmpty() || postojiOdgovor(odgovor)) {
            Drawable invalidBackground = getResources().getDrawable(R.drawable.invalid_background);
            etOdgovor.setBackground(invalidBackground);
            return;
        }else {
            etOdgovor.setBackground(editTextBackground);
        }

        if (tacan) {
            tacanOdgovor = odgovor + "";
            btnDodajTacan.setEnabled(false);
        }

        // odgovori.add(odgovor);
        // odgovoriAdapter.notifyDataSetChanged();
        odgovoriAdapter.add(odgovor, tacan);
        etOdgovor.getText().clear();
    }

    private boolean postojiOdgovor(String odgovor) {
        for(String odg : odgovori) {
            if(odg.equals(odgovor))
                return true;
        }
        return false;
    }

    private void setUpRemovingAnswer() {
        lvOdgovori.setOnItemClickListener((parent, view, position, id) -> {
            String odabraniOdgovor = odgovoriAdapter.getItem(position);
            if(odabraniOdgovor != null && odabraniOdgovor.equals(tacanOdgovor)) {
                tacanOdgovor = null;
                btnDodajTacan.setEnabled(true);
            }
            // odgovori.remove(position);
            // odgovoriAdapter.notifyDataSetChanged();
            odgovoriAdapter.remove(odabraniOdgovor);
        });
    }

    private void setUpOnQuestionComplete() {
        btnDodajPitanje.setOnClickListener(view -> {
            String nazivPitanja = etNaziv.getText().toString().trim();
            String odgovor = etOdgovor.getText().toString().trim();
            Drawable invalidBackground = getResources().getDrawable(R.drawable.invalid_background);

            pitanjeDAO.get(nazivPitanja, result -> {
                boolean nazivValid = !nazivPitanja.isEmpty() && result == null;
                boolean odgovorValid = !postojiOdgovor(odgovor);
                boolean tacanValid = tacanOdgovor != null;

                if(nazivValid) {
                    etNaziv.setBackground(editTextBackground);
                }else {
                    etNaziv.setBackground(invalidBackground);
                }

                if(odgovorValid) {
                    etOdgovor.setBackground(editTextBackground);
                }else {
                    etOdgovor.setBackground(invalidBackground);
                }

                if(!tacanValid) {
                    Toast toast = Toast.makeText(this, "Ne postoji tacan odgovor!", Toast.LENGTH_LONG);
                    toast.show();
                    etOdgovor.setBackground(invalidBackground);
                }

                if(nazivValid && odgovorValid && tacanValid)
                    finishPitanje();
            });
        });
    }

    private void finishPitanje() {
        Intent intent = new Intent();
        intent.putExtra("pitanje", newPitanjeFromData());
        setResult(RESULT_OK, intent);
        finish();
    }

    private Pitanje newPitanjeFromData() {
        Pitanje novoPitanje = new Pitanje();

        novoPitanje.setNaziv(etNaziv.getText().toString().trim());
        novoPitanje.setTekstPitanja(novoPitanje.getNaziv());
        novoPitanje.setOdgovori(odgovori);
        novoPitanje.setTacan(tacanOdgovor);

        return novoPitanje;
    }
}
