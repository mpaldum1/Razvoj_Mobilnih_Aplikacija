package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizAdapter extends ArrayAdapter<Kviz> {
    private int resource;

    public KvizAdapter(Context context, int resource, List<Kviz> objects) {
        super(context, resource, objects);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout linearLayout;
        if (convertView == null) {
            linearLayout = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().getSystemService(inflater);
            li.inflate(resource, linearLayout, true);
        } else {
            linearLayout = (LinearLayout)convertView;
        }

        Kviz kviz = getItem(position);

        ImageView iconImage = linearLayout.findViewById(R.id.icon);
        TextView naziv = linearLayout.findViewById(R.id.nazivKviza);
        TextView brojPitanja = linearLayout.findViewById(R.id.brojPitanja);

        naziv.setText(kviz.getNaziv());

        if(brojPitanja != null) {
            if(kviz.equals(KvizoviAkt.kvizDodaj))
                brojPitanja.setText("");
            else
                brojPitanja.setText(String.valueOf(kviz.getPitanja().size()));
        }

        if(position == getCount() - 1)
            iconImage.setImageResource(R.drawable.add_quiz);
        else {
            int iconId = kviz.getKategorija().getId();
            Icon icon = IconHelper.getInstance(getContext()).getIcon(iconId);
            if(icon != null) {
                Drawable drawable = icon.getDrawable(getContext());
                drawable.setTint(parent.getResources().getColor(R.color.colorBlueButton));
                iconImage.setImageDrawable(drawable);
            }else {
                iconImage.setImageResource(R.drawable.dot_quiz);
            }
        }

        return linearLayout;
    }

}
