package ba.unsa.etf.rma.DAL.firebase;

import ba.unsa.etf.rma.network.JsonHandler;

public interface ObjectToJsonFactory<T> {
    void objectToJson(T object, JsonHandler handler);
}
