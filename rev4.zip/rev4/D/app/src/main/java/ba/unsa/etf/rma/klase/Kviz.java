package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;

public class Kviz  implements Serializable {
    private String naziv;
    private Kategorija kategorija;
    private ArrayList<Pitanje> pitanja;

    public Kviz() {
        pitanja = new ArrayList<>();
    }

    public Kviz(String naziv, Kategorija kategorija, ArrayList<Pitanje> pitanja) {
        setNaziv(naziv);
        setKategorija(kategorija);
        setPitanja(pitanja);
    }

    public void dodajPitanje(Pitanje pitanje) {
        pitanja.add(pitanje);
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String Naziv) {
        this.naziv = Naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> Pitanja) {
        this.pitanja = Pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija Kategorija) {
        this.kategorija = Kategorija;
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
