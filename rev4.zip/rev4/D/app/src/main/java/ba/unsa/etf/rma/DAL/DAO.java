package ba.unsa.etf.rma.DAL;

import java.util.ArrayList;

import ba.unsa.etf.rma.network.JsonHandler;

public interface DAO<T> {
    void getAll(ResultHandler<ArrayList<T>> resultHandler);
    void get(String id, ResultHandler<T> resultHandler);
    void add(T object, JsonHandler responseHandler);
    void update(T object, JsonHandler responseHandler);
    void delete(String id, JsonHandler responseHandler);
}
