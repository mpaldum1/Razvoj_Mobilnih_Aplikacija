package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;

public class Ranglista implements Serializable {
    private String nazivKviza;
    private ArrayList<Rang> ranglista;

    public Ranglista() {
        this("", new ArrayList<>());
    }

    public Ranglista(String nazivKviza, ArrayList<Rang> ranglista) {
        this.nazivKviza = nazivKviza;
        this.ranglista = ranglista;
    }

    public void addScore(int rang, String imeIgraca, double procenatTacnih) {
        ranglista.add(new Rang(rang, imeIgraca, procenatTacnih));
    }

    public String getNazivKviza() {
        return nazivKviza;
    }

    public void setNazivKviza(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }

    public ArrayList<Rang> getRanglista() {
        return ranglista;
    }

    public void setRanglista(ArrayList<Rang> ranglista) {
        this.ranglista = ranglista;
    }
}
