package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.DAL.firebase.KategorijaDAO;
import ba.unsa.etf.rma.Notifier;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {
    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajIkonu;
    private Button btnDodajKategoriju;

    private Drawable editTextDrawable;
    private Icon[] selectedIcons;
    private final KategorijaDAO kategorijaDAO = KategorijaDAO.getInstance();


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kategoriju_akt);

        etNaziv = findViewById(R.id.etNaziv);
        etIkona = findViewById(R.id.etIkona);
        btnDodajIkonu = findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = findViewById(R.id.btnDodajKategoriju);
        etIkona.setEnabled(false);
        editTextDrawable = etNaziv.getBackground();

        setUpCategoryComplete();
        setUpAddingIcon();
    }

    private void setUpCategoryComplete() {
        btnDodajKategoriju.setOnClickListener(view -> {
            Drawable invalidBackground = getResources().getDrawable(R.drawable.invalid_background);

            String iconID = etIkona.getText().toString().trim();
            String categName = etNaziv.getText().toString().trim();

            kategorijaDAO.get(categName, result -> {
                boolean iconValid = !iconID.isEmpty();
                boolean nameValid = !categName.isEmpty() && result == null;

                if(iconValid) {
                    etIkona.setBackground(editTextDrawable);
                }else {
                    etIkona.setBackground(invalidBackground);
                }

                if(nameValid) {
                    etNaziv.setBackground(editTextDrawable);
                }else {
                    etNaziv.setBackground(invalidBackground);
                }

                if(result != null) {
                    Notifier.displayAlert(this, "Unesena kategorija već postoji!");
                }

                if(iconValid && nameValid)
                    finishCategory();
            });
        });
    }

    private void finishCategory() {
        // TODO: 6/11/19 Ako ima konekcije dodati!!!! Moze se desiti da nestane bas tad!
        kategorijaDAO.add(newCategoryFromData(), json -> {
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
        });
    }

    private Kategorija newCategoryFromData() {
        Kategorija novaKategorija = new Kategorija();
        novaKategorija.setNaziv(etNaziv.getText().toString().trim());
        int id = Integer.parseInt(etIkona.getText().toString().trim());
        novaKategorija.setId(id);
        return novaKategorija;
    }

    private void setUpAddingIcon() {
        IconDialog iconDialog = new IconDialog();
        selectedIcons = new Icon[1];
        btnDodajIkonu.setOnClickListener(view -> {
            iconDialog.show(getSupportFragmentManager(), "icon_dialog");
        });
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        String id = Integer.toString(selectedIcons[0].getId());
        etIkona.setText(id);
    }
}
