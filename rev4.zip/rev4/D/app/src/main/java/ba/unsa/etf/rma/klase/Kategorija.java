package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Kategorija implements Serializable {
    private String naziv;
    private int id;

    public Kategorija() {

    }

    public Kategorija(String naziv, int id) {
        this.naziv = naziv;
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String Naziv) {
        this.naziv = Naziv;
    }

    public int getId() {
        return id;
    }

    public void setId(int Id) {
        this.id = Id;
    }

    @Override
    public String toString() {
        return getNaziv();
    }

    @Override
    public boolean equals(Object obj) {
        return ((Kategorija) obj).getNaziv().equals(getNaziv());
    }
}
