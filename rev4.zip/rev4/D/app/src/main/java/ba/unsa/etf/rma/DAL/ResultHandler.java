package ba.unsa.etf.rma.DAL;

@FunctionalInterface
public interface ResultHandler<T> {
    void execute(T object);
}
