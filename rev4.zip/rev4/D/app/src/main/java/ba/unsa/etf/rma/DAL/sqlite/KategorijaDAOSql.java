package ba.unsa.etf.rma.DAL.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.network.JsonHandler;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Kategorija;

public class KategorijaDAOSql implements DAO<Kategorija> {
    private final SQLiteDatabase db;

    public KategorijaDAOSql(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Kategorija>> resultHandler) {
        Cursor cursor = db.query(DatabaseHelper.TABLE_KATEGORIJE, null, null,null,null,null,null);

        ArrayList<Kategorija> kategorije = new ArrayList<>();
        while(cursor.moveToNext()) {
            kategorije.add(getFromCursor(cursor));
        }

        cursor.close();
        resultHandler.execute(kategorije);
    }

    @Override
    public void get(String id, ResultHandler<Kategorija> resultHandler) {
        String selection = "(naziv = ?)";
        String[] args = new String[] {id};
        Cursor cursor = db.query(DatabaseHelper.TABLE_KATEGORIJE, null, selection,args,null,null,null);
        cursor.moveToFirst();
        Kategorija kategorija = getFromCursor(cursor);
        cursor.close();
        resultHandler.execute(kategorija);
    }

    private Kategorija getFromCursor(Cursor cursor) {
        if(cursor == null || cursor.getCount() == 0)
            return null;

        Kategorija kategorija = new Kategorija();

        String naziv = cursor.getString(cursor.getColumnIndexOrThrow("naziv"));
        int idIkonice = cursor.getInt(cursor.getColumnIndexOrThrow("idIkonice"));

        kategorija.setNaziv(naziv);
        kategorija.setId(idIkonice);

        return kategorija;
    }

    @Override
    public void add(Kategorija kategorija, JsonHandler responseHandler) {
        get(kategorija.getNaziv(), res -> {
            if(res != null)
                return;

            ContentValues kategValues = new ContentValues();
            kategValues.putNull("id");
            kategValues.put("naziv", kategorija.getNaziv());
            kategValues.put("idIkonice", kategorija.getId());
            db.insert(DatabaseHelper.TABLE_KATEGORIJE, null, kategValues);
        });
        responseHandler.execute(null);
    }

    @Override
    public void update(Kategorija object, JsonHandler responseHandler) {

    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {

    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        // FIXME: 6/17/19 Potencijalna greska!!!
        db.close();
    }
}
