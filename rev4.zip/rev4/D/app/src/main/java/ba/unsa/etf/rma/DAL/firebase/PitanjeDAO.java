package ba.unsa.etf.rma.DAL.firebase;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.network.FirebaseURLBuilder;
import ba.unsa.etf.rma.network.GetRequest;
import ba.unsa.etf.rma.network.PatchRequest;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.network.JsonHandler;

public class PitanjeDAO implements DAO<Pitanje>, JsonToObjectFactory<Pitanje>, ObjectToJsonFactory<Pitanje> {
    private static PitanjeDAO instance;
    private final String COLLECTION = "Pitanja";

    private PitanjeDAO() {

    }

    public static PitanjeDAO getInstance() {
        if(instance == null)
            instance = new PitanjeDAO();
        return  instance;
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Pitanje>> resultHandler) {
        new GetRequest(json -> {
            ArrayList<Pitanje> pitanja = new ArrayList<>();

            try {
                JSONArray documents = json.getJSONArray("documents");

                for(int i = 0; i < documents.length(); i++) {
                    JSONObject document = documents.getJSONObject(i);
                    JSONObject fields = document.getJSONObject("fields");
                    jsonToObject(fields, pitanja::add);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                resultHandler.execute(pitanja);
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION));
    }

    @Override
    public void get(String id, ResultHandler<Pitanje> resultHandler) {
        new GetRequest(json -> {
            try {
                if(json != null) {
                    JSONObject fields = json.getJSONObject("fields");
                    jsonToObject(fields, resultHandler);
                }else {
                    resultHandler.execute(null);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION, id));
    }

    @Override
    public void add(Pitanje object, JsonHandler responseHandler) {
        objectToJson(object, result ->
                new PatchRequest(responseHandler, String.valueOf(result))
                        .execute(FirebaseURLBuilder.getUrl(COLLECTION, object.getNaziv()))
        );
    }

    @Override
    public void update(Pitanje object, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void jsonToObject(JSONObject json, ResultHandler<Pitanje> handler) {
        Pitanje pitanje = new Pitanje("pitanje", "pitanje", new ArrayList<>(), "tacan");

        try {
            String naziv = json.getJSONObject("naziv").getString("stringValue");
            pitanje.setNaziv(naziv);

            JSONArray odgovoriJson = json.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
            for(int i = 0; i < odgovoriJson.length(); i++) {
                String odgovor = odgovoriJson.getJSONObject(i).getString("stringValue");
                pitanje.getOdgovori().add(odgovor);
            }

            int indexTacnog = json.getJSONObject("indexTacnog").getInt("integerValue");
            pitanje.setTacan(pitanje.getOdgovori().get(indexTacnog));
        } catch (JSONException e) {
            Log.e("Failed parse", "Failed to parse Pitanje: " + json);
            pitanje = null;
        }

        handler.execute(pitanje);
    }

    @Override
    public void objectToJson(Pitanje object, JsonHandler handler) {
        int indexTacnog = object.getOdgovori().indexOf(object.getTacan());
        String naziv = object.getNaziv();
        String odgovori = "";

        for(int i = 0; i < object.getOdgovori().size(); i++) {
            odgovori += "{\"stringValue\":\"" + object.getOdgovori().get(i) + "\"}";
            if(i < object.getOdgovori().size() - 1)
                odgovori += ",";
        }


        String json = "{\"fields\": {\n" +
                "  \"indexTacnog\": {\n" +
                "   \"integerValue\": \"" + indexTacnog + "\"\n" +
                "  },\n" +
                "  \"naziv\": {\n" +
                "   \"stringValue\": \"" + naziv + "\"\n" +
                "  },\n" +
                "  \"odgovori\": {\n" +
                "   \"arrayValue\": {\n" +
                "    \"values\": [\n" +
                odgovori +
                "    ]\n" +
                "   }\n" +
                "  }\n" +
                " }}";

        try {
            JSONObject fields = new JSONObject(json);
            handler.execute(fields);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
