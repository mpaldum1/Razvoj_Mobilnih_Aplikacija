package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kviz;

public class DetailFrag extends Fragment {
    private GridView gridKvizovi;

    private KvizoviAkt activity;
    private ArrayAdapter<Kviz> kvizAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.detail_frag, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        gridKvizovi = view.findViewById(R.id.gridKvizovi);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        activity = (KvizoviAkt) getActivity();

        ArrayList<Kviz> kvizovi = activity.getKvizovi();
        kvizAdapter = new KvizAdapter(getContext(), R.layout.kviz_grid_item, kvizovi);
        gridKvizovi.setAdapter(kvizAdapter);

        gridKvizovi.setOnItemClickListener((parent, view, position, id) -> {
            Kviz kviz = kvizAdapter.getItem(position);
            activity.openQuizPlay(kviz);
        });

        gridKvizovi.setOnItemLongClickListener((parent, view, position, id) -> {
            Kviz kviz = kvizAdapter.getItem(position);
            activity.openQuizAddOrEdit(kviz);
            return true;
        });
    }

    public void notifyAdapter() {
        kvizAdapter.notifyDataSetChanged();
    }


}
