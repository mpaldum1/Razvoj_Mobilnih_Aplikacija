package ba.unsa.etf.rma.network;

import org.json.JSONObject;

@FunctionalInterface
public interface JsonHandler {
    void execute(JSONObject json);
}
