package ba.unsa.etf.rma.DAL.sqlite;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.network.JsonHandler;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Ranglista;

public class RanglistaDAOSql implements DAO<Ranglista> {
    @Override
    public void getAll(ResultHandler<ArrayList<Ranglista>> resultHandler) {

    }

    @Override
    public void get(String id, ResultHandler<Ranglista> resultHandler) {

    }

    @Override
    public void add(Ranglista object, JsonHandler responseHandler) {

    }

    @Override
    public void update(Ranglista object, JsonHandler responseHandler) {

    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {

    }
}
