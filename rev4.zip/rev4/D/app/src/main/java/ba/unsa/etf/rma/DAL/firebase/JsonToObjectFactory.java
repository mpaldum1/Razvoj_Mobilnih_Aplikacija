package ba.unsa.etf.rma.DAL.firebase;

import org.json.JSONObject;

import ba.unsa.etf.rma.DAL.ResultHandler;

public interface JsonToObjectFactory<T> {
    void jsonToObject(JSONObject json, ResultHandler<T> handler);
}
