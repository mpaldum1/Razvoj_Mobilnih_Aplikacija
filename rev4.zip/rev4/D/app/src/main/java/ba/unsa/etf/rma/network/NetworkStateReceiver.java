package ba.unsa.etf.rma.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class NetworkStateReceiver extends BroadcastReceiver {
    private NetworkStateListener listener;
    private boolean connected = false;
    private boolean firstCheck = true;

    public NetworkStateReceiver(NetworkStateListener listener) {
        this.listener = listener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent == null || intent.getExtras() == null)
            return;

        if(firstCheck) {
            firstCheck = false;
            updateConnectionStatus(context);
            notifyState();
        }else {
            if(checkStateChanged(context))
                notifyState();
        }
    }

    public boolean checkStateChanged(Context context) {
        boolean prev = connected;
        updateConnectionStatus(context);
        return prev != connected;
    }

    private void updateConnectionStatus(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        connected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    private void notifyState() {
        if (listener != null) {
            if (connected)
                listener.onNetworkAvailable();
            else
                listener.onNetworkUnavailable();
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public interface NetworkStateListener {
        void onNetworkAvailable();
        void onNetworkUnavailable();
    }
}
