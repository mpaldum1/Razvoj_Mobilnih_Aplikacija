package ba.unsa.etf.rma.DAL.firebase;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.network.FirebaseURLBuilder;
import ba.unsa.etf.rma.network.GetRequest;
import ba.unsa.etf.rma.network.JsonHandler;
import ba.unsa.etf.rma.network.PatchRequest;
import ba.unsa.etf.rma.network.PostRequest;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Rang;
import ba.unsa.etf.rma.klase.Ranglista;

public class RanglistaDAO implements DAO<Ranglista>, ObjectToJsonFactory<Ranglista>, JsonToObjectFactory<Ranglista> {
    private static RanglistaDAO instance;
    private final String COLLECTION = "Rangliste";

    private RanglistaDAO() {}

    public static RanglistaDAO getInstance() {
        if(instance == null)
            instance = new RanglistaDAO();
        return instance;
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Ranglista>> resultHandler) {
        // not implemented
    }

    public void getByKvizName(String nazivKviza, ResultHandler<Ranglista> resultHandler) {
        String structuredQuery = "{\n" +
                " \"structuredQuery\": {\n" +
                "  \"where\": {\n" +
                "   \"fieldFilter\": {\n" +
                "    \"field\": {\n" +
                "     \"fieldPath\": \"nazivKviza\"\n" +
                "    },\n" +
                "    \"op\": \"EQUAL\",\n" +
                "    \"value\": {\n" +
                "     \"stringValue\": \""+nazivKviza+"\"\n" +
                "    }\n" +
                "   }\n" +
                "  },\n" +
                "  \"from\": [\n" +
                "   {\n" +
                "    \"collectionId\": \"Rangliste\"\n" +
                "   }\n" +
                "  ]\n" +
                " }\n" +
                "}";

        new PostRequest(json -> {
            try {
                if(json == null)
                    return;

                JSONArray documents = json.getJSONArray("documents");
                JSONObject item = documents.getJSONObject(0);
                JSONObject document = item.getJSONObject("document");
                JSONObject fields = document.getJSONObject("fields");
                jsonToObject(fields, resultHandler);
            } catch (JSONException e) {
                Log.e("Failed query", "Something is wrong with the json object in Ranglista query");
                e.printStackTrace();
            }
        }, structuredQuery).execute(FirebaseURLBuilder.getQueryUrl());
    }
    
    @Override
    public void get(String id, ResultHandler<Ranglista> resultHandler) {
        new GetRequest(json -> {
            try {
                if(json != null) {
                    JSONObject fields = json.getJSONObject("fields");
                    jsonToObject(fields, resultHandler);
                }else {
                    resultHandler.execute(null);
                }
            } catch (JSONException e) {
                Log.e("JSON Error", "Could not find 'fields'");
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION, id));
    }

    @Override
    public void add(Ranglista object, JsonHandler responseHandler) {
        objectToJson(object, result ->
                new PatchRequest(responseHandler, String.valueOf(result))
                        .execute(FirebaseURLBuilder.getUrl(COLLECTION, "rl_" + object.getNazivKviza()))
        );
    }

    @Override
    public void update(Ranglista object, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void jsonToObject(JSONObject json, ResultHandler<Ranglista> handler) {
        Ranglista ranglista = new Ranglista();

        try {
            String nazivKviza = json.getJSONObject("nazivKviza").getString("stringValue");
            ranglista.setNazivKviza(nazivKviza);

            JSONObject rangFields = json.getJSONObject("lista").getJSONObject("mapValue").getJSONObject("fields");
            for(int i = 1; i <= rangFields.length(); i++) {
                JSONObject igrac = rangFields.getJSONObject("" + i).getJSONObject("mapValue").getJSONObject("fields");
                String nazivIgraca = igrac.keys().next();
                double procenatTacnih = igrac.getJSONObject(nazivIgraca).getDouble("doubleValue");

                Rang rang = new Rang(i, nazivIgraca, procenatTacnih);
                ranglista.getRanglista().add(rang);
            }

            handler.execute(ranglista);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("Ranglista", "greska pri konstrukciji: " + e.getMessage());
        }
    }

    @Override
    public void objectToJson(Ranglista object, JsonHandler handler) {
        String nazivKviza = object.getNazivKviza();
        String scores = "";

        for(int i = 0; i < object.getRanglista().size(); i++) {
            Rang rang = object.getRanglista().get(i);
            scores += " \"" + rang.getRang() + "\": {\n" +
                    "      \"mapValue\": {\n" +
                    "       \"fields\": {\n" +
                    "        \"" + rang.getImeIgraca() + "\": {\n" +
                    "         \"doubleValue\": " + rang.getProcenatTacnih() + "\n" +
                    "        }\n" +
                    "       }\n" +
                    "      }\n" +
                    "     }";

            if(i < object.getRanglista().size() - 1)
                scores += ",";
        }

        String json = "{\n" +
                " \"fields\": {\n" +
                "  \"nazivKviza\": {\n" +
                "   \"stringValue\": \"" + nazivKviza + "\"\n" +
                "  },\n" +
                "  \"lista\": {\n" +
                "   \"mapValue\": {\n" +
                "    \"fields\": {\n" +
                scores +
                "    }\n" +
                "   }\n" +
                "  }\n" +
                " }\n" +
                "}";

        try {
            JSONObject fields = new JSONObject(json);
            handler.execute(fields);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
