package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import ba.unsa.etf.rma.CalendarEvents;
import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.DAL.firebase.KategorijaDAO;
import ba.unsa.etf.rma.DAL.firebase.KvizDAO;
import ba.unsa.etf.rma.DAL.sqlite.KategorijaDAOSql;
import ba.unsa.etf.rma.DAL.sqlite.KvizDAOSql;
import ba.unsa.etf.rma.LoaderDialog;
import ba.unsa.etf.rma.Notifier;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.network.NetworkStateReceiver;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.network.Authentication;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizoviAkt extends AppCompatActivity implements NetworkStateReceiver.NetworkStateListener {
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;
    private FrameLayout listPlace;
    private FrameLayout detailPlace;

    private ArrayAdapter categoryAdapter;
    private ArrayAdapter quizAdapter;

    private ArrayList<Kviz> kvizovi;
    private ArrayList<Kategorija> kategorije;

    private DetailFrag detailFrag;
    private ListaFrag listaFrag;

    private final KvizDAO kvizDAO = KvizDAO.getInstance();
    private final KategorijaDAO kategorijaDAO = KategorijaDAO.getInstance();
    private KvizDAOSql kvizDAOSql;
    private KategorijaDAOSql kategorijaDAOSql;

    public static final Kategorija kategorijaSvi = new Kategorija("Svi", 0);
    public static final Kviz kvizDodaj = new Kviz("Dodaj kviz", kategorijaSvi, new ArrayList<>());
    private Kategorija trenutnaKategorija = kategorijaSvi;

    private NetworkStateReceiver networkStateReceiver;

    public static final int QUIZ_FAILED = 0;
    public static final int ADD_QUIZ = 1;
    public static final int EDIT_QUIZ = 2;
    public static final int QUIZ_OK = 4;
    public static final int PLAY_REQUEST = 5;
    public static final int REQUEST_CALENDAR_READ = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);

        spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = findViewById(R.id.lvKvizovi);
        listPlace = findViewById(R.id.listPlace);
        detailPlace = findViewById(R.id.detailPlace);

        kvizDAOSql = new KvizDAOSql(this);
        kategorijaDAOSql = new KategorijaDAOSql(this);

        init();

        networkStateReceiver = new NetworkStateReceiver(this);
        registerReceiver(networkStateReceiver, new IntentFilter(android.net.ConnectivityManager.CONNECTIVITY_ACTION));
    }

    private void init() {
        kvizovi =  new ArrayList<>();
        kvizovi.add(kvizDodaj);
        kategorije = new ArrayList<>();
        kategorije.add(kategorijaSvi);
        trenutnaKategorija = kategorijaSvi;

        if(isWideLayout()) {
            initFragments();
        } else {
            initAdaptersAndListeners();
        }
    }

    private boolean isWideLayout() {
        return listPlace != null && detailPlace != null;
    }

    private void initFragments() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        listaFrag = new ListaFrag();
        transaction.add(listPlace.getId(), listaFrag);

        detailFrag = new DetailFrag();
        transaction.add(detailPlace.getId(), detailFrag);

        transaction.commit();
    }

    private void initAdaptersAndListeners() {
        // Category adapter
        categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPostojeceKategorije.setAdapter(categoryAdapter);

        // Quiz adapter
        quizAdapter = new KvizAdapter(this, R.layout.kviz_list_item, kvizovi);
        lvKvizovi.setAdapter(quizAdapter);

        // Filter quizzes
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija kategorija = (Kategorija) spPostojeceKategorije.getSelectedItem();
                setTrenutnaKategorija(kategorija);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Open Quiz add/edit
        lvKvizovi.setOnItemLongClickListener((parent, view, position, id) -> {
                openQuizAddOrEdit(kvizovi.get(position));
            return true;
        });

        // Open quiz play
        lvKvizovi.setOnItemClickListener((parent, view, position, id) -> {
            openQuizPlay(kvizovi.get(position));
        });
    }

    private void reloadKategorijeAndKvizovi() {
        // TODO: 6/17/19 Networks state check
        DAO<Kategorija> tKategorijaDAO = networkStateReceiver.isConnected() ? kategorijaDAO : kategorijaDAOSql;

        LoaderDialog.showLoader(this);
        tKategorijaDAO.getAll(result -> {
            kategorije.clear();
            kategorije.add(kategorijaSvi);
            kategorije.addAll(result);
            notifyCategoryAdapter();
            reloadKvizovi();
        });
    }

    private void reloadKvizovi() {
        // TODO: 6/17/19 Network state check
        LoaderDialog.showLoader(this);
        if(networkStateReceiver.isConnected())
            kvizDAO.getAllByCategoryId(trenutnaKategorija.getNaziv(), this::postReloadKvizovi);
        else
            kvizDAOSql.getAllByCategoryId(trenutnaKategorija.getNaziv(), this::postReloadKvizovi);
    }

    private void postReloadKvizovi(ArrayList<Kviz> result) {
        kvizovi.clear();
        kvizovi.addAll(result);
        kvizovi.add(kvizDodaj);
        notifyQuizAdapter();
        LoaderDialog.hideLoader();

        // syncJosNeRadi, popraviti bazu prvo lokalnu :/
        if(networkStateReceiver.isConnected())
            syncToLocal();
    }

    private void notifyCategoryAdapter() {
        if(isWideLayout()) {
            listaFrag.notifyAdapter();
        }else {
            categoryAdapter.notifyDataSetChanged();
        }
    }

    private void notifyQuizAdapter() {
        if(isWideLayout()) {
            detailFrag.notifyAdapter();
        }else {
            quizAdapter.notifyDataSetChanged();
        }
    }

    public void openQuizAddOrEdit(Kviz kviz) {
        // TODO: 6/17/19 Network state check
        if(!networkStateReceiver.isConnected())
            return;

        Intent intent = new Intent(this, DodajKvizAkt.class);

        int requestCode;

        if(kviz.equals(kvizDodaj)) {
            kviz = new Kviz("", kategorijaSvi, new ArrayList<>());
            requestCode = ADD_QUIZ;
        }else {
            requestCode = EDIT_QUIZ;
        }

        intent.putExtra("kvizId", kviz.getNaziv());
        intent.putExtra("requestCode", requestCode);
        startActivityForResult(intent, requestCode);
    }

    public void openQuizPlay(Kviz kviz) {
        if(kviz.equals(kvizDodaj))
            return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                if(shouldShowRequestPermissionRationale(Manifest.permission.READ_CALENDAR)) {
                    Toast.makeText(this, "Dozvolite koristenje kalendara da biste igrali kviz.", Toast.LENGTH_SHORT).show();
                }
                requestPermissions(new String[]{Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR_READ);
            }else {
                playQuiz(kviz);
            }
        }else {
            playQuiz(kviz);
        }
    }

    private void playQuiz(Kviz kviz) {
        if(kviz.equals(kvizDodaj))
            return;

        // TODO: 6/17/19 Network state check
        DAO<Kviz> tKvizDAO = networkStateReceiver.isConnected() ? kvizDAO : kvizDAOSql;

        tKvizDAO.get(kviz.getNaziv(), result -> {
            int minutes = (int) Math.ceil(result.getPitanja().size() / 2.0);
            if(calendarHasEventIn(minutes)) {
                Notifier.displayAlert(this, "Imate događaj u kalendaru za " + minutes + " minuta!");
                return;
            }

            Intent intent = new Intent(this, IgrajKvizAkt.class);
            intent.putExtra("kviz", result);
            startActivityForResult(intent, PLAY_REQUEST);
        });
    }

    private boolean calendarHasEventIn(int minutes) {
        long nextEventEpochMilis = CalendarEvents.getNextEventTime(this);
        if(nextEventEpochMilis == -1)
            return false;

        long current = new Date().getTime();
        long diferenceInMinutes = (nextEventEpochMilis - current) / 60000;

        Log.e("CALENDAR", "dtstart: " + new Date(nextEventEpochMilis) + ", current: " + current);

        Log.e("TIME", diferenceInMinutes + ", stop? " + (diferenceInMinutes <= minutes));

        return diferenceInMinutes <= minutes;
    }

    public ArrayList<Kviz> getKvizovi() {
        return kvizovi;
    }

    public ArrayList<Kategorija> getKategorije() {
        return kategorije;
    }

    public void setTrenutnaKategorija(Kategorija kategorija) {
        trenutnaKategorija = kategorija;
        reloadKvizovi();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        reloadKategorijeAndKvizovi();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CALENDAR_READ) {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Sada mozete igrati kvizove!", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "Ne mozete igrati kvizove dok ne dozvolite koristenje kalendara!", Toast.LENGTH_SHORT).show();
            }
        }else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    public void onNetworkAvailable() {
        Toast.makeText(this, "Connected", Toast.LENGTH_SHORT).show();
        new Authentication(this, json -> reloadKategorijeAndKvizovi()).execute();
    }

    private void syncToLocal() {
        for(Kviz kviz : kvizovi) {
            kvizDAOSql.addOrUpdate(kviz);
        }
    }

    @Override
    public void onNetworkUnavailable() {
        Toast.makeText(this, "Not Connected", Toast.LENGTH_SHORT).show();
        reloadKategorijeAndKvizovi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(networkStateReceiver);
    }
}
