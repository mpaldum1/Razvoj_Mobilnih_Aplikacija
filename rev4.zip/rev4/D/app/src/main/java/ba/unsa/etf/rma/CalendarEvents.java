package ba.unsa.etf.rma;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import java.util.Date;

public class CalendarEvents {
    public static final String[] EVENT_PROJECTION = new String[] {
            CalendarContract.Events._ID,
            CalendarContract.Events.DTSTART
    };

    private static final int PROJECTION_ID_INDEX = 0;
    private static final int PROJECTION_START_TIME = 1;

    public static long getNextEventTime(Activity context) {
        ContentResolver cr = context.getContentResolver();
        Uri uri = CalendarContract.Events.CONTENT_URI;
        String sortOrder = CalendarContract.Events.DTSTART + " ASC";
        String selection = "(" + CalendarContract.Events.DTSTART + " >= ?)";
        String[] selectionArgs = new String[] { String.valueOf(new Date().getTime()) };
        Cursor cur = cr.query(uri, EVENT_PROJECTION, selection, selectionArgs, sortOrder);

        if(cur == null || cur.getCount() == 0)
            return -1;

        cur.moveToFirst();
        long dtstart = cur.getLong(PROJECTION_START_TIME);
        cur.close();

        return dtstart;
    }
}
