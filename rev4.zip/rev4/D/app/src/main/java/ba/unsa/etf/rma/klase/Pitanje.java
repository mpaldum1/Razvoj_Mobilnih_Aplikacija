package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;

public class Pitanje implements Serializable {
    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori;
    private String tacan;

    public Pitanje() {
        odgovori = new ArrayList<>();
    }

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan) {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
    }

    public ArrayList<String> dajRandomOdgovore() {
        ArrayList<String> randOdg = new ArrayList<>(odgovori);
        Collections.shuffle(randOdg);
        return randOdg;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String Naziv) {
        this.naziv = Naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String TekstPitanja) {
        this.tekstPitanja = TekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> Odgovori) {
        this.odgovori = Odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String Tacan) {
        this.tacan = Tacan;
    }

    @Override
    public String toString() {
        return getNaziv();
    }

    @Override
    public boolean equals(Object obj) {
        Pitanje pitanje = (Pitanje) obj;
        return pitanje.getNaziv().equals(getNaziv());
    }
}
