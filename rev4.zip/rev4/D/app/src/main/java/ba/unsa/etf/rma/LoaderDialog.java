package ba.unsa.etf.rma;

import android.app.AlertDialog;
import android.content.Context;

public class LoaderDialog {
    private static AlertDialog loaderDialog;

    private LoaderDialog() {}

    public static void showLoader(Context context) {
        if(loaderDialog == null) {
            loaderDialog = new AlertDialog.Builder(context)
                    .setView(R.layout.loader_dialog)
                    .setCancelable(false)
                    .show();
        }
    }

    public static void hideLoader() {
        if(loaderDialog != null) {
            loaderDialog.dismiss();
            loaderDialog = null;
        }
    }
}
