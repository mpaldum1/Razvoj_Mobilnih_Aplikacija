package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Kviz;

public class InformacijeFrag extends Fragment {
    private Button btnKraj;
    private TextView infNazivKviza;
    private TextView infBrojTacnih;
    private TextView infBrojPreostalih;
    private TextView infProcenatTacnih;

    private IgrajKvizAkt activity;
    private Kviz trenutniKviz;
    private int ukupanBrojPitanja;
    private int brojTacnih;
    private int brojPreostalih;
    private double procenatTacnih;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.informacije_frag, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnKraj = view.findViewById(R.id.btnKraj);
        infNazivKviza = view.findViewById(R.id.infNazivKviza);
        infBrojTacnih = view.findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalih = view.findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacnih = view.findViewById(R.id.infProcenatTacni);

        activity = (IgrajKvizAkt) getActivity();
        trenutniKviz = (Kviz) getArguments().getSerializable("kviz");

        initData(trenutniKviz);
        updateStats();

        btnKraj.setOnClickListener(v -> {
            activity.endGame();
        });
    }

    public void updateStats() {
        infBrojTacnih.setText(String.valueOf(brojTacnih));
        infBrojPreostalih.setText(String.valueOf(brojPreostalih));
        infProcenatTacnih.setText(String.valueOf(procenatTacnih));
        updateProcenatTacnih();
    }

    private void initData(Kviz kviz) {
        infNazivKviza.setText(kviz.getNaziv());
        ukupanBrojPitanja = kviz.getPitanja().size();
        brojTacnih = 0;
        brojPreostalih = ukupanBrojPitanja-1;
    }

    public void increaseTacnih() {
        brojTacnih += 1;
        if(brojTacnih > ukupanBrojPitanja)
            brojTacnih = ukupanBrojPitanja;
    }

    public void decreasePreostalih() {
        brojPreostalih -= 1;
        if(brojPreostalih < 0)
            brojPreostalih = 0;
    }

    public double getProcenatTacnih() {
        return procenatTacnih;
    }

    private void updateProcenatTacnih() {
        if(ukupanBrojPitanja != 0)
            procenatTacnih = (double) brojTacnih / (ukupanBrojPitanja-brojPreostalih) * 100;
        else
            procenatTacnih = 0;

        infProcenatTacnih.setText(String.format(Locale.getDefault(),"%.2f%%", procenatTacnih));
    }

}
