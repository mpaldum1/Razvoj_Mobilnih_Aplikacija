package ba.unsa.etf.rma.network;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

public class PostRequest extends AsyncTask<URL, Void, JSONObject> {
    private JsonHandler method;
    private JSONObject result;
    private String body;

    public PostRequest(JsonHandler method, String body) {
        this.method = method;
        this.body = body;
    }

    @Override
    protected JSONObject doInBackground(URL... urls) {
        URL url = urls[0];
        HttpsURLConnection connection = null;

        try {
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);

            OutputStream os = connection.getOutputStream();
            byte[] input = body.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);

            InputStream is = null;
            try {
                is = connection.getInputStream();
            }catch(IOException e) {
                is = connection.getErrorStream();
            }

            String jsonStr = "{\"documents\":";
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
            String responseLine;
            while((responseLine = bufferedReader.readLine()) != null)
                jsonStr += responseLine;

            jsonStr += "}";
            result = new JSONObject(jsonStr);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if(connection != null)
                connection.disconnect();
        }

        return result;
    }

    @Override
    protected void onPostExecute(JSONObject json) {
        super.onPostExecute(json);
        method.execute(result);
    }
}
