package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import ba.unsa.etf.rma.DAL.firebase.KvizDAO;
import ba.unsa.etf.rma.DAL.firebase.RanglistaDAO;
import ba.unsa.etf.rma.LoaderDialog;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RanglistaFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.Rang;
import ba.unsa.etf.rma.klase.Ranglista;

public class IgrajKvizAkt extends AppCompatActivity {
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private InformacijeFrag informacijeFrag;
    private PitanjeFrag pitanjeFrag;
    private RanglistaFrag ranglistaFrag;

    private Kviz trenutniKviz;
    private ArrayList<Pitanje> pitanja;
    private int trenutnoPitanjeIdx;

    private final RanglistaDAO ranglistaDAO = RanglistaDAO.getInstance();
    private final KvizDAO kvizDAO = KvizDAO.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igraj_kviz_akt);

        trenutniKviz = (Kviz) getIntent().getSerializableExtra("kviz");
        pitanja = trenutniKviz.getPitanja();
        Collections.shuffle(pitanja);

        setUpFragments();

        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.informacijePlace, informacijeFrag);
        if(pitanjeFrag != null)
            fragmentTransaction.add(R.id.pitanjePlace, pitanjeFrag);
        fragmentTransaction.commit();

        int startInMinutes = pitanja.size() / 2;
        startAlarm(startInMinutes);
    }

    private void startAlarm(int minutes) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        Date date = new Date();

        Log.e("time", date.getHours() + ":" + date.getMinutes());
        // FIXME: 6/17/19 Popraviti overflow minuta!!!
        
        int minutesToAlarm = date.getMinutes() + minutes;
        if(date.getSeconds() > 0 || minutes == 0)
            minutesToAlarm += 1;

        intent.putExtra(AlarmClock.EXTRA_HOUR, date.getHours());
        intent.putExtra(AlarmClock.EXTRA_MINUTES, minutesToAlarm);
        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        startActivity(intent);
    }

    private void setUpFragments() {
        informacijeFrag = new InformacijeFrag();
        Bundle infBundle = new Bundle();
        infBundle.putSerializable("kviz", trenutniKviz);
        informacijeFrag.setArguments(infBundle);

        loadPitanjeFrag();
    }

    private void loadPitanjeFrag() {
        if(pitanja.isEmpty() || trenutnoPitanjeIdx == pitanja.size()) {
            showScoreDialog();
            return;
        }

        pitanjeFrag = new PitanjeFrag();
        Bundle pitBundle = new Bundle();
        Pitanje trenutno = pitanja.get(trenutnoPitanjeIdx);
        pitBundle.putSerializable("pitanje", trenutno);
        pitanjeFrag.setArguments(pitBundle);
    }

    private void showScoreDialog() {
        EditText input = new EditText(this);

        new AlertDialog.Builder(this)
                .setTitle("Unesite ime:")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Done", (dialog, which) -> {
                    showScoreBoard(input.getText().toString().trim());
                })
                .show();
    }

    private void showScoreBoard(String imeIgraca) {
        // TODO: 6/17/19 Check network!!!
        LoaderDialog.showLoader(this);
        RanglistaDAO.getInstance().get("rl_" + trenutniKviz.getNaziv(), ranglista -> {
            if(ranglista == null) {
                ranglista = new Ranglista(trenutniKviz.getNaziv(), new ArrayList<>());
            }

            ranglista.getRanglista().add(new Rang(0, imeIgraca, informacijeFrag.getProcenatTacnih()));
            Collections.sort(ranglista.getRanglista());
            for(int i = 0; i < ranglista.getRanglista().size(); i++) {
                ranglista.getRanglista().get(i).setRang(i+1);
            }

            LoaderDialog.hideLoader();

            Ranglista finalRanglista = ranglista;
            ranglistaDAO.add(ranglista, json -> startRanglistaFrag(finalRanglista));
        });
    }

    private void startRanglistaFrag(Ranglista ranglista) {
        try {
            fragmentTransaction = fragmentManager.beginTransaction();
            if(pitanjeFrag != null) {
                fragmentTransaction.remove(pitanjeFrag);
                pitanjeFrag = null;
            }
            loadRangListFrag(ranglista);
            fragmentTransaction.add(R.id.pitanjePlace, ranglistaFrag);
            fragmentTransaction.commit();
        } catch (IllegalStateException e) {
            //
        }
    }

    private void loadRangListFrag(Ranglista ranglista) {
        ranglistaFrag = new RanglistaFrag();
        Bundle bundle = new Bundle();
        bundle.putSerializable("ranglista", ranglista);
        ranglistaFrag.setArguments(bundle);
    }

    public void endGame() {
        Intent intent = new Intent();
        setResult(KvizoviAkt.PLAY_REQUEST, intent);
        finish();
    }

    public void answerQuestion(boolean correct) {
        if(correct)
            informacijeFrag.increaseTacnih();

        informacijeFrag.decreasePreostalih();
        informacijeFrag.updateStats();
        trenutnoPitanjeIdx += 1;
        new Handler().postDelayed(this::nextQuestion, 2000);
    }

    private void nextQuestion() {
        try {
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.remove(pitanjeFrag);
            loadPitanjeFrag();
            fragmentTransaction.add(R.id.pitanjePlace, pitanjeFrag);
            fragmentTransaction.commit();
        } catch (IllegalStateException e) {
            //
        }
    }

}
