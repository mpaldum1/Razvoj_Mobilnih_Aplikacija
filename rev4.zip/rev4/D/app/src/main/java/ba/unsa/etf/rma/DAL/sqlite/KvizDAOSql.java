package ba.unsa.etf.rma.DAL.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.network.JsonHandler;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizDAOSql implements DAO<Kviz> {
    private final SQLiteDatabase db;
    private KategorijaDAOSql kategorijaDAOSql;
    private PitanjeDAOSql pitanjeDAOSql;

    public KvizDAOSql(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        kategorijaDAOSql = new KategorijaDAOSql(context);
        pitanjeDAOSql = new PitanjeDAOSql(context);
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Kviz>> resultHandler) {
        Cursor cursor = db.query(DatabaseHelper.TABLE_KVIZOVI, null, null, null,null,null,null);
        getAllFromCursor(cursor, resultHandler, null);
    }

    public void getAllByCategoryId(String categoryId, ResultHandler<ArrayList<Kviz>> resultHandler) {
        if(categoryId.equals(KvizoviAkt.kategorijaSvi.getNaziv())) {
            getAll(resultHandler);
            return;
        }

        String selection = "idKategorije = ?";
        String[] args = new String[] {categoryId};
        Cursor cursor = db.query(DatabaseHelper.TABLE_KVIZOVI, null, selection,args,null,null,null);

        kategorijaDAOSql.get(categoryId, kategorija ->
                getAllFromCursor(cursor, resultHandler, kategorija)
        );
    }

    private void getAllFromCursor(Cursor cursor, ResultHandler<ArrayList<Kviz>> resultHandler, Kategorija kategorija) {
        ArrayList<Kviz> kvizovi = new ArrayList<>();

        if(kategorija == null)
            kategorija = KvizoviAkt.kategorijaSvi;

        while(cursor.moveToNext()) {
            kvizovi.add(getFromCursorWithKnownKategorija(cursor, kategorija));
        }

        cursor.close();
        resultHandler.execute(kvizovi);
    }

    private Kviz getFromCursorWithKnownKategorija(Cursor cursor, Kategorija kategorija) {
        if(cursor == null || cursor.getCount() == 0)
            return null;

        Kviz kviz = new Kviz();

        String naziv = cursor.getString(cursor.getColumnIndexOrThrow("naziv"));

        kviz.setNaziv(naziv);
        kviz.setKategorija(kategorija);
        ArrayList<Pitanje> pitanja = pitanjeDAOSql.loadPitanjaKviza(kviz);
        kviz.setPitanja(pitanja);

        return kviz;
    }

    private Kviz getFromCursor(Cursor cursor) {
        if(cursor == null || cursor.getCount() == 0)
            return null;

        Kviz kviz = new Kviz();

        String naziv = cursor.getString(cursor.getColumnIndexOrThrow("naziv"));
        String idKategorije = cursor.getString(cursor.getColumnIndexOrThrow("idKategorije"));

        kviz.setNaziv(naziv);
        kategorijaDAOSql.get(idKategorije, kviz::setKategorija);
        ArrayList<Pitanje> pitanja = pitanjeDAOSql.loadPitanjaKviza(kviz);
        kviz.setPitanja(pitanja);

        return kviz;
    }

    @Override
    public void get(String id, ResultHandler<Kviz> resultHandler) {
        String selection = "(naziv = ?)";
        String[] args = new String[] {id};
        Cursor cursor = db.query(DatabaseHelper.TABLE_KVIZOVI, null, selection,args,null,null,null);
        cursor.moveToFirst();
        Kviz kviz = getFromCursor(cursor);
        cursor.close();
        resultHandler.execute(kviz);
    }

    public void addOrUpdate(Kviz kviz) {
        get(kviz.getNaziv(), res -> {
            if(res == null) {
                add(kviz, json -> {});
            }else {
                update(kviz, json -> {});
            }
        });
    }

    @Override
    public void add(Kviz kviz, JsonHandler responseHandler) {
        kategorijaDAOSql.add(kviz.getKategorija(), json -> {});

        ContentValues kvizValues = new ContentValues();
        kvizValues.putNull("id");
        kvizValues.put("naziv", kviz.getNaziv());
        kvizValues.put("idKategorije", kviz.getKategorija().getNaziv());
        db.insert(DatabaseHelper.TABLE_KVIZOVI, null, kvizValues);

        if(kviz.getPitanja() == null)
            kviz.setPitanja(new ArrayList<>());

        for(Pitanje pitanje : kviz.getPitanja()) {
            pitanjeDAOSql.addPitanjeToKviz(pitanje, kviz);
        }

        responseHandler.execute(null);
    }

    @Override
    public void update(Kviz kviz, JsonHandler responseHandler) {
        // TODO: 6/17/19 Uradi pametnije klotsu, u firebase takodjer =)
        delete(kviz.getNaziv(), res -> add(kviz, responseHandler));
    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {
        String where = "naziv = ?";
        String[] args = new String[] {id};
        db.delete(DatabaseHelper.TABLE_KVIZOVI, where, args);
        responseHandler.execute(null);
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        // FIXME: 6/17/19 Potencijalna greska!!!
        db.close();
    }
}
