package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import ba.unsa.etf.rma.DAL.firebase.KategorijaDAO;
import ba.unsa.etf.rma.DAL.firebase.KvizDAO;
import ba.unsa.etf.rma.DAL.firebase.PitanjeDAO;
import ba.unsa.etf.rma.LoaderDialog;
import ba.unsa.etf.rma.Notifier;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity {
    private EditText nameInput;
    private Spinner kategorijeSpinner;
    private ListView listDodanaPitanja;
    private ListView listMogucaPitanja;
    private Button dodajKviz;
    private Button importKviz;

    private ArrayAdapter<Kategorija> spinnerAdapter;
    private ArrayAdapter<Pitanje> dodanaAdapter;
    private ArrayAdapter<Pitanje> mogucaAdapter;

    private ArrayList<Kategorija> kategorije;
    private ArrayList<Pitanje> mogucaPitanja;
    private ArrayList<Pitanje> dodanaPitanja;

    private Drawable textEditDefault;
    private Drawable spinnerDefault;

    private Kviz recievedQuiz;

    private Kategorija dodajKategoriju = new Kategorija("Dodaj kategoriju", 0);
    private Pitanje dodajPitanje = new Pitanje("Dodaj pitanje", null, null, null);

    private final KvizDAO kvizDAO = KvizDAO.getInstance();
    private final KategorijaDAO kategorijaDAO = KategorijaDAO.getInstance();
    private final PitanjeDAO pitanjeDAO = PitanjeDAO.getInstance();

    private static int ADD_PITANJE = 1;
    private static int ADD_KATEGORIJA = 2;
    private static int READ_REQUEST = 42;
    private int requestCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodaj_kviz_akt);

        nameInput = findViewById(R.id.etNaziv);
        kategorijeSpinner = findViewById(R.id.spKategorije);
        listDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        listMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        dodajKviz = findViewById(R.id.btnDodajKviz);
        importKviz = findViewById(R.id.btnImportKviz);

        textEditDefault = nameInput.getBackground();
        spinnerDefault = kategorijeSpinner.getBackground();

        String recievedQuizId = getIntent().getStringExtra("kvizId");
        requestCode = getIntent().getIntExtra("requestCode", 0);

        if(recievedQuizId == null || recievedQuizId.isEmpty()) {
            recievedQuiz = new Kviz("", KvizoviAkt.kategorijaSvi, new ArrayList<>());
            initSetUp();
        }else {
            LoaderDialog.showLoader(this);
            kvizDAO.get(recievedQuizId, kviz -> {
                recievedQuiz = kviz;
                initSetUp();
            });
        }
    }

    private void initSetUp() {
        mogucaPitanja = new ArrayList<>();
        kategorije = new ArrayList<>();
        dodanaPitanja = new ArrayList<>();

        setUpSpinnerAdapter();
        setUpMogucaAdapter();
        setUpDodanaAdapter();

        onReloadKategorije(result -> {
            reloadKategorije(result);
            loadQuizToForm(recievedQuiz);

            setUpAddingCategories();
            setUpQuestionExchange();
            setUpOnButtonComplete();
            setUpImportButton();
        });
    }

    private void loadQuizToForm(Kviz kviz) {
        LoaderDialog.showLoader(this);

        dodanaPitanja.clear();
        dodanaPitanja.addAll(kviz.getPitanja());
        dodanaPitanja.add(dodajPitanje);
        dodanaAdapter.notifyDataSetChanged();
        nameInput.setText(kviz.getNaziv());

        pitanjeDAO.getAll(svaPitanja -> {
            loadMogucaPitanja(svaPitanja);

            if(!kategorije.contains(kviz.getKategorija()))
                kategorijaDAO.add(kviz.getKategorija(), json -> onReloadKategorije(this::reloadKategorije));

            int pos = spinnerAdapter.getPosition(kviz.getKategorija());
            kategorijeSpinner.setSelection(pos);

            LoaderDialog.hideLoader();
        });
    }

    private void loadMogucaPitanja(ArrayList<Pitanje> svaPitanja) {
        for(Pitanje zaIzbaciti : recievedQuiz.getPitanja()) {
            svaPitanja.remove(zaIzbaciti);
        }
        mogucaPitanja.clear();
        mogucaPitanja.addAll(svaPitanja);
        mogucaAdapter.notifyDataSetChanged();
    }

    private void onReloadKategorije(ResultHandler<ArrayList<Kategorija>> resultHandler) {
        kategorije.clear();
        kategorijaDAO.getAll(resultHandler);
    }

    private void reloadKategorije(ArrayList<Kategorija> list) {
        kategorije.add(KvizoviAkt.kategorijaSvi);
        kategorije.addAll(list);
        kategorije.add(dodajKategoriju);
        spinnerAdapter.notifyDataSetChanged();
    }

    private void setUpDodanaAdapter() {
        dodanaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dodanaPitanja);
        listDodanaPitanja.setAdapter(dodanaAdapter);
    }

    private void setUpMogucaAdapter() {
        mogucaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, mogucaPitanja);
        listMogucaPitanja.setAdapter(mogucaAdapter);
    }

    private void setUpSpinnerAdapter() {
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        kategorijeSpinner.setAdapter(spinnerAdapter);
    }

    private void setUpAddingCategories() {
        kategorijeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija selected = kategorije.get(position);

                if(selected.equals(dodajKategoriju)) {
                    startCategoryAdding();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void startCategoryAdding() {
        Intent intent = new Intent(this, DodajKategorijuAkt.class);
        startActivityForResult(intent, ADD_KATEGORIJA);
    }

    private void setUpQuestionExchange() {
        listDodanaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            if(position == listDodanaPitanja.getCount() - 1) {
                startQuestionAdding();
            }else {
                Pitanje pitanje = dodanaPitanja.get(position);
                moveQuestion(pitanje, dodanaPitanja, mogucaPitanja);
                dodanaAdapter.notifyDataSetChanged();
                mogucaAdapter.notifyDataSetChanged();
            }
        });

        listMogucaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            Pitanje pitanje = mogucaPitanja.get(position);
            moveQuestion(pitanje, mogucaPitanja, dodanaPitanja);
            dodanaAdapter.notifyDataSetChanged();
            mogucaAdapter.notifyDataSetChanged();
        });
    }

    private void moveQuestion(Pitanje pitanje, ArrayList<Pitanje> from, ArrayList<Pitanje> to) {
        int idx = from.indexOf(pitanje);
        if(idx == -1)
            return;
        Pitanje temp = from.remove(idx);
        to.add(0, temp);
    }

    private void startQuestionAdding() {
        Intent intent = new Intent(this, DodajPitanjeAkt.class);
        startActivityForResult(intent, ADD_PITANJE);
    }

    private void setUpOnButtonComplete() {
        dodajKviz.setOnClickListener(event -> {
            Intent intent = new Intent();
            Drawable background = getResources().getDrawable(R.drawable.invalid_background);
            String nazivKviza = nameInput.getText().toString().trim();

            // provjeri da li kviz postoji u bazi
            LoaderDialog.showLoader(this);
            kvizDAO.get(nazivKviza, kviz -> {
                if(requestCode == KvizoviAkt.ADD_QUIZ) {
                    boolean valid = !nazivKviza.isEmpty() && kviz == null;

                    // TODO: 6/11/19 Ako ima konekcije onda dodati kviz!!!

                    if(valid) {
                        setResult(KvizoviAkt.QUIZ_OK, intent);
                        kvizDAO.add(newKvizFromData(), json -> {
                            nameInput.setBackground(textEditDefault);
                            LoaderDialog.hideLoader();
                            finish();
                        });
                    }else {
                        nameInput.setBackground(background);
                        LoaderDialog.hideLoader();
                    }
                }else {
                    boolean valid = kviz == null || recievedQuiz.getNaziv().equals(kviz.getNaziv());

                    if(valid) {
                        setResult(KvizoviAkt.QUIZ_OK, intent);
                        kvizDAO.delete(recievedQuiz.getNaziv(), json -> {
                            kvizDAO.add(newKvizFromData(), json2 -> {
                                nameInput.setBackground(textEditDefault);
                                LoaderDialog.hideLoader();
                                finish();
                            });
                        });
                    }else {
                        nameInput.setBackground(background);
                        LoaderDialog.hideLoader();
                    }
                }
            });
        });
    }

    private Kviz newKvizFromData() {
        Kviz toRet = new Kviz();
        toRet.setNaziv(nameInput.getText().toString().trim());
        toRet.setKategorija((Kategorija) kategorijeSpinner.getSelectedItem());
        dodanaPitanja.remove(dodajPitanje);
        toRet.setPitanja(new ArrayList<>());
        toRet.getPitanja().addAll(dodanaPitanja);
        return toRet;
    }

    private void setUpImportButton() {
        importKviz.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            String[] mimeTypes = {"text/csv", "text/plain", "text/comma-separated-values"};
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            startActivityForResult(intent, READ_REQUEST);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK) {
            if(requestCode == ADD_KATEGORIJA)
                kategorijeSpinner.setSelection(0);
            return;
        }

        if(requestCode == ADD_KATEGORIJA) {
            kategorijeSpinner.setBackground(spinnerDefault);
            onReloadKategorije(this::reloadKategorije);
        }else if(requestCode == ADD_PITANJE) {
            Pitanje novoPitanje = (Pitanje) data.getSerializableExtra("pitanje");

            // TODO: 6/11/19 Ako ima konekcije dodati pitanje!!!
            
            pitanjeDAO.add(novoPitanje, json -> {
                dodanaPitanja.add(dodanaPitanja.size()-1, novoPitanje);
                listDodanaPitanja.smoothScrollToPosition(dodanaAdapter.getCount()-1);
                dodanaAdapter.notifyDataSetChanged();
            });
        }else if(requestCode == READ_REQUEST) {
            if(data == null)
                return;
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                loadQuizToForm(getQuizFromInput(inputStream));
            } catch (FileNotFoundException e) {
                Notifier.displayAlert(this, "Greska prilikom otvaranja datoteke!");
            } catch (IllegalArgumentException e) {
                Notifier.displayAlert(this, e.getMessage());
            } catch (Exception e) {
                Notifier.displayAlert(this,"Datoteka kviza kojeg importujete nema ispravan format!");
            }
        }
    }

    private Kviz getQuizFromInput(InputStream input) {
        Kviz kviz = new Kviz();
        int brojPitanja = 0;

        Scanner scanner = new Scanner(input);

        if(scanner.hasNextLine()) {
            String[] data = scanner.nextLine().split(",");
            String naziv = data[0];
            String kategorija = data[1];
            brojPitanja = Integer.parseInt(data[2]);

            LoaderDialog.showLoader(this);
            kvizDAO.get(naziv, result -> {
                LoaderDialog.hideLoader();
                if(result != null)
                    throw new IllegalArgumentException("Kviz kojeg importujete već postoji!");
            });

            kviz.setNaziv(naziv);
            kviz.setKategorija(new Kategorija(kategorija, 0));
        }else {
            throw new IllegalArgumentException("Datoteka kviza kojeg importujete nema ispravan format!");
        }

        ArrayList<Pitanje> pitanja = new ArrayList<>();

        int counter = 0;
        while(counter < brojPitanja && scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] data = line.split(",");

            String naziv = data[0];
            int brojOdgovora = Integer.parseInt(data[1]);
            int idxTacnogOdgovora = Integer.parseInt(data[2]);

            if(brojOdgovora <= 0 || data.length - 3 != brojOdgovora)
                throw new IllegalArgumentException("Kviz kojeg importujete ima neispravan broj odgovora!");

            if(idxTacnogOdgovora < 0 || idxTacnogOdgovora >= brojOdgovora)
                throw new IllegalArgumentException("Kviz kojeg importujete ima neispravan index tačnog odgovora!");

            ArrayList<String> odgovori = new ArrayList<>();

            for(int i = 3; i < data.length; i++) {
                if(odgovori.contains(data[i]))
                    throw new IllegalArgumentException("Kviz nije ispravan postoje dva ista odgovora!");
                odgovori.add(data[i]);
            }

            Pitanje pitanje = new Pitanje(naziv, naziv, odgovori, odgovori.get(idxTacnogOdgovora));

            if(pitanja.contains(pitanje))
                throw new IllegalArgumentException("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");

            pitanja.add(pitanje);

            counter += 1;
        }

        if(counter != brojPitanja || scanner.hasNextLine())
            throw new IllegalArgumentException("Kviz kojeg importujete ima neispravan broj pitanja!");

        kviz.setPitanja(pitanja);

        return kviz;
    }
}
