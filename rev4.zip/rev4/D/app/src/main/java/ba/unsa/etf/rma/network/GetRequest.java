package ba.unsa.etf.rma.network;

import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;

public class GetRequest extends AsyncTask<URL, Void, JSONObject> {
    private JsonHandler method;
    private JSONObject result;

    public GetRequest(JsonHandler method) {
        this.method = method;
    }

    @Override
    protected JSONObject doInBackground(URL... urls) {
        URL url = urls[0];
        String json = "";
        HttpsURLConnection connection = null;

        try {
            connection = (HttpsURLConnection) url.openConnection();
            Scanner sc = new Scanner(connection.getInputStream());

            while(sc.hasNextLine())
                json += sc.nextLine();

            result = new JSONObject(json);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } finally {
            if(connection != null)
                connection.disconnect();
        }

        return result;
    }

    @Override
    protected void onPostExecute(JSONObject json) {
        super.onPostExecute(json);
        method.execute(result);
    }
}
