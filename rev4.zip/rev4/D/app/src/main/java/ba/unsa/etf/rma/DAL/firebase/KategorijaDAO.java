package ba.unsa.etf.rma.DAL.firebase;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ba.unsa.etf.rma.DAL.DAO;
import ba.unsa.etf.rma.network.FirebaseURLBuilder;
import ba.unsa.etf.rma.network.GetRequest;
import ba.unsa.etf.rma.network.PatchRequest;
import ba.unsa.etf.rma.DAL.ResultHandler;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.network.JsonHandler;

public class KategorijaDAO implements DAO<Kategorija>, JsonToObjectFactory<Kategorija>, ObjectToJsonFactory<Kategorija> {
    private static KategorijaDAO instance;
    private final String COLLECTION = "Kategorije";

    private KategorijaDAO() {}

    public static KategorijaDAO getInstance() {
        if(instance == null)
            instance = new KategorijaDAO();
        return instance;
    }

    @Override
    public void getAll(ResultHandler<ArrayList<Kategorija>> resultHandler) {
        new GetRequest(json -> {
            ArrayList<Kategorija> kategorije = new ArrayList<>();

            try {
                JSONArray documents = json.getJSONArray("documents");

                for(int i = 0; i < documents.length(); i++) {
                    try {
                        JSONObject document = documents.getJSONObject(i);
                        JSONObject fields = document.getJSONObject("fields");
                        jsonToObject(fields, kategorije::add);
                    }catch (JSONException e) {
                        Log.e("Kategorija", "Failed to add...");
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }finally {
                resultHandler.execute(kategorije);
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION));
    }

    @Override
    public void get(String id, ResultHandler<Kategorija> resultHandler) {
        new GetRequest(json -> {
            try {
                if(json != null) {
                    JSONObject fields = json.getJSONObject("fields");
                    jsonToObject(fields, resultHandler);
                }else {
                    resultHandler.execute(null);
                }
            } catch (JSONException e) {
                Log.e("JSON Error", "Could not find 'fields'");
            }
        }).execute(FirebaseURLBuilder.getUrl(COLLECTION, id));
    }

    @Override
    public void add(Kategorija object, JsonHandler responseHandler) {
        objectToJson(object, result ->
            new PatchRequest(responseHandler, String.valueOf(result))
                    .execute(FirebaseURLBuilder.getUrl(COLLECTION, object.getNaziv()))
        );
    }

    @Override
    public void update(Kategorija object, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void delete(String id, JsonHandler responseHandler) {
        // not implemented
    }

    @Override
    public void jsonToObject(JSONObject json, ResultHandler<Kategorija> handler) {
        Kategorija kategorija = new Kategorija("invalid", 0);

        try {
            String naziv = json.getJSONObject("naziv").getString("stringValue");
            int idIkonice = json.getJSONObject("idIkonice").getInt("integerValue");
            kategorija.setNaziv(naziv);
            kategorija.setId(idIkonice);
        } catch (JSONException e) {
            Log.e("Failed parse", "Failed to parse Kategorija: " + json);
            kategorija = null;
        }

        handler.execute(kategorija);
    }

    @Override
    public void objectToJson(Kategorija object, JsonHandler handler) {
        String naziv = object.getNaziv();
        int idIkonice = object.getId();

        String json = "{\n" +
                " \"fields\": {\n" +
                "  \"naziv\": {\n" +
                "   \"stringValue\": \"" + naziv + "\"\n" +
                "  },\n" +
                "  \"idIkonice\": {\n" +
                "   \"integerValue\": \"" + idIkonice + "\"\n" +
                "  }\n" +
                " }\n" +
                "}";

        try {
            JSONObject fields = new JSONObject(json);
            handler.execute(fields);
        } catch (JSONException e) {
            Log.e("Failed construction", "Failed to construct Kategorija");
        }
    }
}
