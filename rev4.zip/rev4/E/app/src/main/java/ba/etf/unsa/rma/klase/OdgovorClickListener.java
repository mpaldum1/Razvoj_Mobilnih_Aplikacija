package ba.etf.unsa.rma.klase;

import android.app.Service;

public interface OdgovorClickListener {

    void clicked(boolean tacan);

}
