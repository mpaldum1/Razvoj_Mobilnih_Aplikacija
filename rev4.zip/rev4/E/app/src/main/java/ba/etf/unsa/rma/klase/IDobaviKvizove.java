package ba.etf.unsa.rma.klase;

import java.util.ArrayList;

public interface IDobaviKvizove {
    void processFinish(ArrayList<?> output);
}
