package ba.unsa.etf.rma.enumi;

public class Task {

    public enum TaskType {QUIZ, CATEGORY, QUESTION, RANGLIST};

}
