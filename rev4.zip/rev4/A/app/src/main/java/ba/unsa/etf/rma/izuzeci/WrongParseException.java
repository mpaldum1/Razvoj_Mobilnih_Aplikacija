package ba.unsa.etf.rma.izuzeci;

public class WrongParseException extends RuntimeException {

    public WrongParseException(String msg) {
       super(msg);
    }
}
